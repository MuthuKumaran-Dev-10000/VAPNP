import 'address_model.dart';
export 'address_model.dart';
typedef FamilyProfileModel = AddressModel;
