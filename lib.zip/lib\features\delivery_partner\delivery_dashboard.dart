import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/theme.dart';
import '../../core/services/app_provider.dart';
import '../../core/services/auth_provider.dart';
import '../../core/services/cloudinary_service.dart';
import '../../core/models/order_model.dart';
import '../../core/models/delivery_partner_model.dart';
import '../../widgets/offline_banner.dart';

class DeliveryDashboard extends StatefulWidget {
  const DeliveryDashboard({super.key});

  @override
  State<DeliveryDashboard> createState() => _DeliveryDashboardState();
}

class _DeliveryDashboardState extends State<DeliveryDashboard> {
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final auth = Provider.of<AuthProvider>(context, listen: false);
      final app = Provider.of<AppProvider>(context, listen: false);
      app.listenAllGlobalData();
      if (auth.currentUser != null) {
        app.listenUserSessions(auth.currentUser!.uid, auth.currentUser!.role);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final app = Provider.of<AppProvider>(context);

    if (auth.currentUser == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final String partnerId = auth.currentUser!.uid;

    // Get current partner profile
    DeliveryPartnerModel? partner;
    try {
      partner = app.deliveryPartners.firstWhere((p) => p.id == partnerId);
    } catch (_) {
      // Create fallback if database reference doesn't exist yet
      partner = DeliveryPartnerModel(
        id: partnerId,
        name: auth.currentUser!.name,
        mobile: auth.currentUser!.phone,
        email: auth.currentUser!.email,
        address: 'Delivery Zone',
        bio: auth.currentUser!.bio,
        photo: auth.currentUser!.profilePic,
        rating: 4.8,
        isOnline: true,
        earnings: 0.0,
      );
    }

    // Filters for this delivery partner
    final partnerOrders = app.orders.where((o) => o.deliveryPartnerId == partnerId).toList();
    
    // Check if there is an incoming assignment request
    final OrderModel? incomingRequest = partner.isOnline
        ? app.orders.firstWhere(
            (o) => o.deliveryPartnerId == partnerId && o.status == 'assigning',
            orElse: () => null as dynamic,
          )
        : null;

    final tabs = [
      _DeliveriesTab(orders: partnerOrders, partner: partner, app: app),
      _EarningsTab(orders: partnerOrders, partner: partner),
      _ProfileTab(partner: partner, app: app, auth: auth),
    ];

    return Scaffold(
      backgroundColor: FoodTheme.background,
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.circle,
              color: partner.isOnline ? Colors.green : Colors.grey,
              size: 10,
            ),
            const SizedBox(width: 8),
            Text(
              partner.isOnline ? 'Online • QuickRider' : 'Offline • QuickRider',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: FoodTheme.textDark),
            ),
          ],
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: FoodTheme.secondary),
            onPressed: () async {
              await auth.signOut();
              if (context.mounted) {
                Navigator.of(context).pushReplacementNamed('/');
              }
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          Column(
            children: [
              const OfflineBanner(),
              Expanded(child: tabs[_currentIndex]),
            ],
          ),
          if (incomingRequest != null)
            _buildIncomingRequestOverlay(context, incomingRequest, partner, app),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: FoodTheme.primary,
        unselectedItemColor: FoodTheme.textLight,
        backgroundColor: Colors.white,
        elevation: 10,
        onTap: (index) => setState(() => _currentIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.delivery_dining_outlined), label: 'Tasks'),
          BottomNavigationBarItem(icon: Icon(Icons.currency_rupee_outlined), label: 'Earnings'),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _buildIncomingRequestOverlay(
      BuildContext context, OrderModel order, DeliveryPartnerModel partner, AppProvider app) {
    return Container(
      color: Colors.black54,
      width: double.infinity,
      height: double.infinity,
      child: Center(
        child: Container(
          margin: const EdgeInsets.all(24),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: FoodTheme.cardShadow,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: FoodTheme.primary.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.notifications_active, color: FoodTheme.primary, size: 40),
              ),
              const SizedBox(height: 16),
              const Text(
                'New Delivery Request!',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: FoodTheme.textDark),
              ),
              const SizedBox(height: 8),
              Text(
                'You have been matched for an order.',
                style: TextStyle(color: FoodTheme.textLight, fontSize: 13),
              ),
              const Divider(height: 32),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.storefront, color: FoodTheme.primary, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('PICK UP FROM', style: TextStyle(fontSize: 10, color: FoodTheme.textLight, fontWeight: FontWeight.bold)),
                        Text(order.restaurantName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.location_on, color: FoodTheme.secondary, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('DELIVER TO', style: TextStyle(fontSize: 10, color: FoodTheme.textLight, fontWeight: FontWeight.bold)),
                        Text(order.customerName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        Text(order.deliveryAddress, style: const TextStyle(fontSize: 12, color: FoodTheme.textLight)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Estimated Earnings', style: TextStyle(color: FoodTheme.textLight, fontSize: 13)),
                  Text('₹45.00', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.green)),
                ],
              ),
              const Divider(height: 32),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () async {
                        // Decline logic: Clear delivery partner assignments and return order to accepted state
                        final declined = order.copyWith(
                          deliveryPartnerId: '',
                          deliveryPartnerName: '',
                          status: 'accepted',
                        );
                        await app.updateOrderDetails(declined);
                      },
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: FoodTheme.secondary),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      child: const Text('Decline', style: TextStyle(color: FoodTheme.secondary)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () async {
                        // Accept logic: Change status to accepted (assigned and ready to navigate)
                        final accepted = order.copyWith(status: 'accepted');
                        await app.updateOrderDetails(accepted);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      child: const Text('Accept', style: TextStyle(color: Colors.white)),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}

class _DeliveriesTab extends StatelessWidget {
  final List<OrderModel> orders;
  final DeliveryPartnerModel partner;
  final AppProvider app;

  const _DeliveriesTab({required this.orders, required this.partner, required this.app});

  @override
  Widget build(BuildContext context) {
    final activeOrders = orders
        .where((o) => o.status != 'delivered' && o.status != 'completed' && o.status != 'cancelled' && o.status != 'assigning')
        .toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Partner Status Card
          Card(
            color: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: Colors.grey.shade100)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 26,
                    backgroundImage: NetworkImage(partner.photo),
                    backgroundColor: FoodTheme.primary,
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Welcome back,', style: TextStyle(color: FoodTheme.textLight, fontSize: 12)),
                        Text(partner.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: FoodTheme.textDark)),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: partner.isOnline ? Colors.green.withOpacity(0.1) : Colors.grey.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.circle, color: partner.isOnline ? Colors.green : Colors.grey, size: 8),
                        const SizedBox(width: 6),
                        Text(
                          partner.isOnline ? 'Online' : 'Offline',
                          style: TextStyle(
                            color: partner.isOnline ? Colors.green : Colors.grey,
                            fontWeight: FontWeight.bold,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Active Deliveries Section
          const Text('Active Deliveries', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: FoodTheme.textDark)),
          const SizedBox(height: 12),
          if (activeOrders.isEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 40.0),
                child: Column(
                  children: [
                    Icon(Icons.sports_motorsports_outlined, color: FoodTheme.textLight, size: 48),
                    const SizedBox(height: 12),
                    const Text('No active delivery tasks assigned.', style: TextStyle(color: FoodTheme.textLight)),
                  ],
                ),
              ),
            )
          else
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: activeOrders.length,
              itemBuilder: (context, index) {
                final order = activeOrders[index];
                return _buildTaskCard(context, order);
              },
            ),
        ],
      ),
    );
  }

  Widget _buildTaskCard(BuildContext context, OrderModel order) {
    return Card(
      color: Colors.white,
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: Colors.grey.shade100)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Task ID: #${order.id.substring(order.id.length - 6).toUpperCase()}', style: const TextStyle(fontWeight: FontWeight.bold)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: FoodTheme.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    order.status.toUpperCase().replaceAll('_', ' '),
                    style: const TextStyle(color: FoodTheme.primary, fontWeight: FontWeight.bold, fontSize: 10),
                  ),
                ),
              ],
            ),
            const Divider(height: 24),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.storefront, color: FoodTheme.primary, size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('PICKUP FROM', style: TextStyle(fontSize: 10, color: FoodTheme.textLight, fontWeight: FontWeight.bold)),
                      Text(order.restaurantName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.location_on, color: FoodTheme.secondary, size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('DELIVER TO', style: TextStyle(fontSize: 10, color: FoodTheme.textLight, fontWeight: FontWeight.bold)),
                      Text(order.customerName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      Text(order.deliveryAddress, style: const TextStyle(fontSize: 12, color: FoodTheme.textLight)),
                    ],
                  ),
                ),
              ],
            ),
            const Divider(height: 24),
            
            // Task actions
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Payout: ₹45.00', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green)),
                    Text('Amount: ₹${order.amount.toStringAsFixed(0)}', style: const TextStyle(fontSize: 10, color: FoodTheme.textLight)),
                  ],
                ),
                ElevatedButton(
                  onPressed: () async {
                    if (order.status == 'accepted') {
                      // Mark rider arrived at restaurant
                      await app.updateOrderDetails(order.copyWith(status: 'preparing'));
                    } else if (order.status == 'preparing') {
                      // Mark rider picked up order
                      await app.updateOrderDetails(order.copyWith(status: 'picked_up'));
                    } else if (order.status == 'picked_up' || order.status == 'on_the_way') {
                      // Mark order delivered and update partner earnings
                      final updatedOrder = order.copyWith(status: 'delivered');
                      await app.updateOrderDetails(updatedOrder);

                      // Update earnings profile
                      final updatedPartner = partner.copyWith(earnings: partner.earnings + 45.0);
                      await app.updateDeliveryPartnerProfile(updatedPartner);

                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Order delivered! ₹45 added to earnings.'), backgroundColor: Colors.green),
                        );
                      }
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: order.status == 'accepted'
                        ? Colors.blue
                        : (order.status == 'preparing' ? FoodTheme.primary : Colors.green),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text(
                    order.status == 'accepted'
                        ? 'Arrived at Store'
                        : (order.status == 'preparing' ? 'Food Picked Up' : 'Mark Delivered'),
                    style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _EarningsTab extends StatelessWidget {
  final List<OrderModel> orders;
  final DeliveryPartnerModel partner;

  const _EarningsTab({required this.orders, required this.partner});

  @override
  Widget build(BuildContext context) {
    final completedOrders = orders.where((o) => o.status == 'delivered' || o.status == 'completed').toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Total Earnings Card
          Card(
            color: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24), side: BorderSide(color: Colors.grey.shade100)),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Text('Total Earnings', style: TextStyle(color: FoodTheme.textLight, fontSize: 14)),
                  const SizedBox(height: 8),
                  Text('₹${partner.earnings.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 36, color: Colors.green)),
                  const Divider(height: 32),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Column(
                        children: [
                          const Text('Trips', style: TextStyle(fontSize: 11, color: FoodTheme.textLight)),
                          const SizedBox(height: 4),
                          Text('${completedOrders.length}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: FoodTheme.textDark)),
                        ],
                      ),
                      Column(
                        children: [
                          const Text('Rating', style: TextStyle(fontSize: 11, color: FoodTheme.textLight)),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              const Icon(Icons.star, color: Colors.amber, size: 16),
                              const SizedBox(width: 4),
                              Text('${partner.rating}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: FoodTheme.textDark)),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Earning History list
          const Text('Earning History', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: FoodTheme.textDark)),
          const SizedBox(height: 12),
          if (completedOrders.isEmpty)
            const Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 40),
                child: Text('No earnings recorded yet.', style: TextStyle(color: FoodTheme.textLight)),
              ),
            )
          else
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: completedOrders.length,
              itemBuilder: (context, index) {
                final order = completedOrders[index];
                final date = DateTime.fromMillisecondsSinceEpoch(order.createdAt);
                final formattedDate = '${date.day}/${date.month} ${date.hour}:${date.minute.toString().padLeft(2, "0")}';

                return Card(
                  color: Colors.white,
                  margin: const EdgeInsets.only(bottom: 8),
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade100)),
                  child: ListTile(
                    title: Text(order.restaurantName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    subtitle: Text('Delivered to: ${order.customerName} • $formattedDate', style: const TextStyle(fontSize: 11)),
                    trailing: const Text('₹45.00', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }
}

class _ProfileTab extends StatefulWidget {
  final DeliveryPartnerModel partner;
  final AppProvider app;
  final AuthProvider auth;

  const _ProfileTab({required this.partner, required this.app, required this.auth});

  @override
  State<_ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<_ProfileTab> {
  bool _isUploading = false;

  void _pickAvatar() async {
    try {
      final picker = ImagePicker();
      final image = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
      if (image != null) {
        setState(() {
          _isUploading = true;
        });
        final bytes = await image.readAsBytes();
        final url = await CloudinaryService.uploadImageBytes(bytes, image.name, folder: 'uc/delivery_partners/avatar');
        
        final updatedPartner = widget.partner.copyWith(photo: url);
        await widget.app.updateDeliveryPartnerProfile(updatedPartner);
        
        // Also update Auth profile
        if (widget.auth.currentUser != null) {
          final updatedUser = widget.auth.currentUser!.copyWith(profilePic: url);
          await widget.auth.updateUserProfile(updatedUser);
        }

        setState(() {
          _isUploading = false;
        });

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Profile picture updated successfully!'), backgroundColor: Colors.green),
          );
        }
      }
    } catch (e) {
      setState(() {
        _isUploading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Upload failed: $e'), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Profile Details Header
          Card(
            color: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24), side: BorderSide(color: Colors.grey.shade100)),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  Stack(
                    children: [
                      CircleAvatar(
                        radius: 50,
                        backgroundImage: NetworkImage(widget.partner.photo),
                        backgroundColor: FoodTheme.primary,
                      ),
                      if (_isUploading)
                        const Positioned.fill(
                          child: CircleAvatar(
                            backgroundColor: Colors.black45,
                            child: CircularProgressIndicator(color: Colors.white),
                          ),
                        )
                      else
                        Positioned(
                          right: 0,
                          bottom: 0,
                          child: CircleAvatar(
                            backgroundColor: FoodTheme.primary,
                            radius: 16,
                            child: IconButton(
                              icon: const Icon(Icons.camera_alt, size: 14, color: Colors.white),
                              onPressed: _pickAvatar,
                              padding: EdgeInsets.zero,
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Text(widget.partner.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: FoodTheme.textDark)),
                  const SizedBox(height: 4),
                  Text(widget.partner.email, style: TextStyle(color: FoodTheme.textLight, fontSize: 12)),
                  const Divider(height: 32),
                  
                  // Online/Offline Status Switch
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Go Online / Accept Orders', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: FoodTheme.textDark)),
                      Switch(
                        value: widget.partner.isOnline,
                        onChanged: (val) async {
                          final updated = widget.partner.copyWith(isOnline: val);
                          await widget.app.updateDeliveryPartnerProfile(updated);
                        },
                        activeColor: Colors.green,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Vehicle & Hub Details Card
          Card(
            color: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24), side: BorderSide(color: Colors.grey.shade100)),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Rider Vehicle Details', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: FoodTheme.textDark)),
                  const Divider(height: 24),
                  _buildProfileRow('Phone / Contact', widget.partner.mobile, Icons.phone_android),
                  const SizedBox(height: 12),
                  _buildProfileRow('Delivery Zone', widget.partner.address, Icons.map_outlined),
                  const SizedBox(height: 12),
                  _buildProfileRow('Rider Status', widget.partner.isOnline ? 'Online / Active' : 'Offline / Inactive', Icons.radar_outlined),
                  const SizedBox(height: 12),
                  _buildProfileRow('Bio Description', widget.partner.bio, Icons.info_outline),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileRow(String label, String value, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: FoodTheme.primary, size: 20),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(fontSize: 10, color: FoodTheme.textLight, fontWeight: FontWeight.bold)),
              Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: FoodTheme.textDark)),
            ],
          ),
        )
      ],
    );
  }
}
