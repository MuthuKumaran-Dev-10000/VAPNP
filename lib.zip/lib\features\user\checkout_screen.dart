import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import '../../core/theme.dart';
import '../../core/services/auth_provider.dart';
import '../../core/services/app_provider.dart';
import '../../core/models/address_model.dart';
import 'booking_success_screen.dart';
import 'add_family_member_screen.dart';

class CheckoutScreen extends StatefulWidget {
  final String instructions;
  const CheckoutScreen({super.key, this.instructions = ''});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _phoneController;
  late TextEditingController _emailController;
  late TextEditingController _instructionsController;

  late Razorpay _razorpay;
  String _selectedPaymentMethod = 'cod'; // 'cod' or 'razorpay'
  AddressModel? _selectedAddress;

  @override
  void initState() {
    super.initState();
    final auth = Provider.of<AuthProvider>(context, listen: false);
    final app = Provider.of<AppProvider>(context, listen: false);

    _nameController = TextEditingController(text: auth.currentUser?.name ?? '');
    _phoneController = TextEditingController(text: auth.currentUser?.phone ?? '');
    _emailController = TextEditingController(text: auth.currentUser?.email ?? '');
    _instructionsController = TextEditingController(text: widget.instructions);

    if (app.addresses.isNotEmpty) {
      _selectedAddress = app.addresses.first;
    }

    // Initialize Razorpay
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _instructionsController.dispose();
    _razorpay.clear();
    super.dispose();
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) async {
    final app = Provider.of<AppProvider>(context, listen: false);
    final auth = Provider.of<AuthProvider>(context, listen: false);

    final paymentId = response.paymentId ?? 'pay_razorpay_${DateTime.now().millisecondsSinceEpoch}';
    final name = _nameController.text.trim();
    final addressText = _selectedAddress?.addressLine ?? "No Address Provided";

    final firstItem = app.cart.first;
    String restaurantName = 'Restaurant';
    try {
      restaurantName = app.restaurants.firstWhere((r) => r.id == firstItem.foodItem.restaurantId).name;
    } catch (_) {}

    final orderId = await app.checkoutOrder(
      customerId: auth.currentUser!.uid,
      customerName: name,
      deliveryAddress: addressText,
      deliveryInstructions: _instructionsController.text.trim(),
      paymentMethod: 'razorpay',
      paymentRef: paymentId,
    );

    if (mounted) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(
          builder: (_) => BookingSuccessScreen(
            devoteeName: name,
            templeName: restaurantName,
            upiReference: orderId.isNotEmpty ? orderId : paymentId,
          ),
        ),
        (route) => route.isFirst,
      );
    }
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Payment Failed: ${response.message ?? "User cancelled payment"}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('External Wallet Selected: ${response.walletName}'),
          backgroundColor: FoodTheme.primary,
        ),
      );
    }
  }

  void _payWithRazorpay(double amount) {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedAddress == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select or add a delivery address'), backgroundColor: Colors.red),
      );
      return;
    }

    var options = {
      'key': 'rzp_test_SzBkemjjVqb8Ap',
      'amount': (amount * 100).toInt(), // amount in paise
      'name': 'GreenLabs Food',
      'description': 'Payment for food delivery',
      'prefill': {
        'contact': _phoneController.text.trim(),
        'email': _emailController.text.trim(),
      },
      'external': {
        'wallets': ['paytm']
      }
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      debugPrint("Razorpay Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not initialize payment gateway: $e'), backgroundColor: Colors.red),
      );
    }
  }

  void _submitOrderCOD(AppProvider app, AuthProvider auth) async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedAddress == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select or add a delivery address'), backgroundColor: Colors.red),
      );
      return;
    }

    final name = _nameController.text.trim();
    final addressText = _selectedAddress!.addressLine;

    final firstItem = app.cart.first;
    String restaurantName = 'Restaurant';
    try {
      restaurantName = app.restaurants.firstWhere((r) => r.id == firstItem.foodItem.restaurantId).name;
    } catch (_) {}

    final orderId = await app.checkoutOrder(
      customerId: auth.currentUser!.uid,
      customerName: name,
      deliveryAddress: addressText,
      deliveryInstructions: _instructionsController.text.trim(),
      paymentMethod: 'cod',
      paymentRef: 'cod',
    );

    if (mounted) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(
          builder: (_) => BookingSuccessScreen(
            devoteeName: name,
            templeName: restaurantName,
            upiReference: orderId,
          ),
        ),
        (route) => route.isFirst,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final app = Provider.of<AppProvider>(context);

    // Bill Calculations
    final double itemTotal = app.cartTotal;
    final double taxFee = app.taxAmount;
    final double deliveryFee = app.deliveryFee;
    final double grandTotal = app.grandTotal;

    return Scaffold(
      backgroundColor: FoodTheme.background,
      appBar: AppBar(
        title: const Text('Checkout', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: FoodTheme.textDark)),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        iconTheme: const IconThemeData(color: FoodTheme.textDark),
      ),
      body: app.cart.isEmpty
          ? const Center(child: Text('No items to checkout.'))
          : Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16.0),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // 1. ORDER SUMMARY
                          const Text('Order Summary', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: FoodTheme.textDark)),
                          const SizedBox(height: 10),
                          Card(
                            color: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                children: app.cart.map((item) {
                                  final originalPrice = item.foodItem.price;
                                  final discountedPrice = originalPrice - (originalPrice * (item.foodItem.discount / 100));

                                  return ListTile(
                                    dense: true,
                                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                    leading: Icon(
                                      Icons.circle,
                                      color: item.foodItem.isVeg ? Colors.green : Colors.red,
                                      size: 8,
                                    ),
                                    title: Text(
                                      '${item.foodItem.name} (Qty: ${item.quantity})',
                                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: FoodTheme.textDark),
                                    ),
                                    trailing: Text(
                                      '₹${(discountedPrice * item.quantity).toStringAsFixed(0)}',
                                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: FoodTheme.textDark),
                                    ),
                                  );
                                }).toList(),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),

                          // 2. CONTACT DETAILS
                          const Text('Contact Information', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: FoodTheme.textDark)),
                          const SizedBox(height: 10),
                          Card(
                            color: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Column(
                                children: [
                                  TextFormField(
                                    controller: _nameController,
                                    style: const TextStyle(fontSize: 13),
                                    decoration: const InputDecoration(
                                      labelText: 'Name',
                                      prefixIcon: Icon(Icons.person, color: FoodTheme.primary, size: 20),
                                    ),
                                    validator: (v) => v == null || v.isEmpty ? 'Required' : null,
                                  ),
                                  const SizedBox(height: 12),
                                  TextFormField(
                                    controller: _phoneController,
                                    style: const TextStyle(fontSize: 13),
                                    decoration: const InputDecoration(
                                      labelText: 'Contact Phone',
                                      prefixIcon: Icon(Icons.phone, color: FoodTheme.primary, size: 20),
                                    ),
                                    keyboardType: TextInputType.phone,
                                    validator: (v) => v == null || v.length < 10 ? 'Enter valid phone number' : null,
                                  ),
                                  const SizedBox(height: 12),
                                  TextFormField(
                                    controller: _emailController,
                                    style: const TextStyle(fontSize: 13),
                                    decoration: const InputDecoration(
                                      labelText: 'Billing Email',
                                      prefixIcon: Icon(Icons.email, color: FoodTheme.primary, size: 20),
                                    ),
                                    keyboardType: TextInputType.emailAddress,
                                    validator: (v) => v == null || !v.contains('@') ? 'Enter valid email' : null,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),

                          // 3. DELIVERY ADDRESS SELECTOR
                          const Text('Delivery Address', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: FoodTheme.textDark)),
                          const SizedBox(height: 10),
                          Card(
                            color: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  if (app.addresses.isEmpty) ...[
                                    const Text(
                                      'No saved addresses found. Please add an address to continue.',
                                      style: TextStyle(fontSize: 12, color: FoodTheme.textLight),
                                    ),
                                    const SizedBox(height: 12),
                                    ElevatedButton.icon(
                                      onPressed: () {
                                        Navigator.of(context).push(
                                          MaterialPageRoute(builder: (_) => const AddFamilyMemberScreen()),
                                        );
                                      },
                                      icon: const Icon(Icons.add_location_alt_outlined, color: Colors.white),
                                      label: const Text('ADD ADDRESS', style: TextStyle(color: Colors.white)),
                                      style: ElevatedButton.styleFrom(backgroundColor: FoodTheme.primary),
                                    ),
                                  ] else ...[
                                    DropdownButtonFormField<AddressModel>(
                                      value: _selectedAddress,
                                      isExpanded: true,
                                      decoration: const InputDecoration(
                                        labelText: 'Select Saved Address',
                                        prefixIcon: Icon(Icons.location_on, color: FoodTheme.primary),
                                      ),
                                      items: app.addresses.map((addr) {
                                        return DropdownMenuItem<AddressModel>(
                                          value: addr,
                                          child: Text(
                                            '${addr.title}: ${addr.addressLine}',
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(fontSize: 12),
                                          ),
                                        );
                                      }).toList(),
                                      onChanged: (val) {
                                        setState(() {
                                          _selectedAddress = val;
                                        });
                                      },
                                    ),
                                    const SizedBox(height: 12),
                                    TextButton.icon(
                                      onPressed: () {
                                        Navigator.of(context).push(
                                          MaterialPageRoute(builder: (_) => const AddFamilyMemberScreen()),
                                        );
                                      },
                                      icon: const Icon(Icons.add, size: 16, color: FoodTheme.primary),
                                      label: const Text('Add Another Address', style: TextStyle(color: FoodTheme.primary, fontWeight: FontWeight.bold, fontSize: 12)),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),

                          // 4. DELIVERY INSTRUCTIONS
                          const Text('Instructions', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: FoodTheme.textDark)),
                          const SizedBox(height: 10),
                          Card(
                            color: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                              child: TextField(
                                controller: _instructionsController,
                                style: const TextStyle(fontSize: 13),
                                decoration: const InputDecoration(
                                  border: InputBorder.none,
                                  enabledBorder: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: 'Enter cooking or delivery instructions...',
                                  hintStyle: TextStyle(fontSize: 12, color: FoodTheme.textLight),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),

                          // 5. PAYMENT METHOD
                          const Text('Select Payment Mode', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: FoodTheme.textDark)),
                          const SizedBox(height: 10),
                          Card(
                            color: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
                            child: Column(
                              children: [
                                RadioListTile<String>(
                                  title: const Text('Cash On Delivery (COD)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: FoodTheme.textDark)),
                                  subtitle: const Text('Pay with cash when food arrives', style: TextStyle(fontSize: 11, color: FoodTheme.textLight)),
                                  value: 'cod',
                                  groupValue: _selectedPaymentMethod,
                                  activeColor: FoodTheme.primary,
                                  onChanged: (val) {
                                    if (val != null) setState(() => _selectedPaymentMethod = val);
                                  },
                                ),
                                Divider(height: 1, color: Colors.grey.shade100),
                                RadioListTile<String>(
                                  title: const Text('Instant Online Gateway (Razorpay)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: FoodTheme.textDark)),
                                  subtitle: const Text('Cards, Netbanking, UPI (Test Mode)', style: TextStyle(fontSize: 11, color: FoodTheme.textLight)),
                                  value: 'razorpay',
                                  groupValue: _selectedPaymentMethod,
                                  activeColor: FoodTheme.primary,
                                  onChanged: (val) {
                                    if (val != null) setState(() => _selectedPaymentMethod = val);
                                  },
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 20),

                          // 6. BILL DETAILS
                          const Text('Bill Details', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: FoodTheme.textDark)),
                          const SizedBox(height: 10),
                          Card(
                            color: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade200)),
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Text('Item Total', style: TextStyle(fontSize: 12, color: FoodTheme.textLight)),
                                      Text('₹${itemTotal.toStringAsFixed(2)}', style: const TextStyle(fontSize: 12, color: FoodTheme.textDark, fontWeight: FontWeight.w500)),
                                    ],
                                  ),
                                  const SizedBox(height: 10),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Text('GST & Restaurant Taxes (5%)', style: TextStyle(fontSize: 12, color: FoodTheme.textLight)),
                                      Text('₹${taxFee.toStringAsFixed(2)}', style: const TextStyle(fontSize: 12, color: FoodTheme.textDark, fontWeight: FontWeight.w500)),
                                    ],
                                  ),
                                  const SizedBox(height: 10),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Text('Delivery Partner Fee', style: TextStyle(fontSize: 12, color: FoodTheme.textLight)),
                                      Text('₹${deliveryFee.toStringAsFixed(2)}', style: const TextStyle(fontSize: 12, color: FoodTheme.textDark, fontWeight: FontWeight.w500)),
                                    ],
                                  ),
                                  const Divider(height: 24, thickness: 0.8),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Text('Grand Total', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: FoodTheme.textDark)),
                                      Text('₹${grandTotal.toStringAsFixed(2)}', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: FoodTheme.primary)),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                        ],
                      ),
                    ),
                  ),
                ),

                // Sticky Bottom Bar
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, -4)),
                    ],
                  ),
                  child: SafeArea(
                    top: false,
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('₹${grandTotal.toStringAsFixed(2)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: FoodTheme.textDark)),
                              const Text('Grand Total', style: TextStyle(fontSize: 10, color: FoodTheme.textLight, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: app.isLoading
                              ? const Center(child: CircularProgressIndicator(color: FoodTheme.primary))
                              : ElevatedButton(
                                  onPressed: () {
                                    if (_selectedPaymentMethod == 'razorpay') {
                                      _payWithRazorpay(grandTotal);
                                    } else {
                                      _submitOrderCOD(app, auth);
                                    }
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: FoodTheme.primary,
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                                    padding: const EdgeInsets.symmetric(vertical: 14),
                                  ),
                                  child: Text(
                                    _selectedPaymentMethod == 'razorpay' ? 'PAY & PLACE ORDER' : 'PLACE ORDER (COD)',
                                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.white, letterSpacing: 0.5),
                                  ),
                                ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
