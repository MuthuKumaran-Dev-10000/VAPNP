import 'delivery_partner_model.dart';
export 'delivery_partner_model.dart';
typedef PriestModel = DeliveryPartnerModel;
