enum UserRole { customer, restaurant, deliveryPartner }

class UserModel {
  final String uid;
  final String name;
  final String email;
  final String phone;
  final String passwordHash;
  final String securityQuestion;
  final String securityAnswer;
  final String profilePic;
  final String bio;
  final UserRole role;
  final double latitude;
  final double longitude;

  UserModel({
    required this.uid,
    required this.name,
    required this.email,
    required this.phone,
    required this.passwordHash,
    required this.securityQuestion,
    required this.securityAnswer,
    required this.profilePic,
    required this.bio,
    required this.role,
    this.latitude = 0.0,
    this.longitude = 0.0,
  });

  factory UserModel.fromJson(Map<dynamic, dynamic> json, String uid) {
    return UserModel(
      uid: uid,
      name: json['name']?.toString() ?? '',
      email: json['email']?.toString() ?? '',
      phone: json['phone']?.toString() ?? '',
      passwordHash: json['passwordHash']?.toString() ?? '',
      securityQuestion: json['securityQuestion']?.toString() ?? '',
      securityAnswer: json['securityAnswer']?.toString() ?? '',
      profilePic: json['profilePic']?.toString() ?? '',
      bio: json['bio']?.toString() ?? '',
      role: UserRole.values.firstWhere(
        (e) => e.name == json['role']?.toString(),
        orElse: () => UserRole.customer,
      ),
      latitude: double.tryParse(json['latitude']?.toString() ?? '0.0') ?? 0.0,
      longitude: double.tryParse(json['longitude']?.toString() ?? '0.0') ?? 0.0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'email': email,
      'phone': phone,
      'passwordHash': passwordHash,
      'securityQuestion': securityQuestion,
      'securityAnswer': securityAnswer,
      'profilePic': profilePic,
      'bio': bio,
      'role': role.name,
      'latitude': latitude,
      'longitude': longitude,
    };
  }

  UserModel copyWith({
    String? uid,
    String? name,
    String? email,
    String? phone,
    String? passwordHash,
    String? securityQuestion,
    String? securityAnswer,
    String? profilePic,
    String? bio,
    UserRole? role,
    double? latitude,
    double? longitude,
  }) {
    return UserModel(
      uid: uid ?? this.uid,
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      passwordHash: passwordHash ?? this.passwordHash,
      securityQuestion: securityQuestion ?? this.securityQuestion,
      securityAnswer: securityAnswer ?? this.securityAnswer,
      profilePic: profilePic ?? this.profilePic,
      bio: bio ?? this.bio,
      role: role ?? this.role,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
    );
  }
}
