import 'restaurant_model.dart';
export 'restaurant_model.dart';
typedef TempleModel = RestaurantModel;
