import 'dart:async';
import 'dart:math';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';
import '../models/restaurant_model.dart';
import '../models/delivery_partner_model.dart';
import '../models/food_item_model.dart';
import '../models/order_model.dart';
import '../models/address_model.dart';
import '../models/comment_model.dart';
import '../models/notification_model.dart';
import '../models/post_model.dart';

class FirebaseService {
  static final FirebaseService _instance = FirebaseService._internal();
  factory FirebaseService() => _instance;
  FirebaseService._internal() {
    seedOfflineMockData();
  }

  bool get isFirebaseAvailable {
    try {
      return Firebase.apps.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  // Haversine formula to calculate distance in km
  double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    const double p = 0.017453292519943295; // pi / 180
    final double a = 0.5 - cos((lat2 - lat1) * p) / 2 +
        cos(lat1 * p) * cos(lat2 * p) * (1 - cos((lon2 - lon1) * p)) / 2;
    return 12742 * asin(sqrt(a)); // 2 * R; R = 6371 km
  }

  String _buildPathKey(String id, String name) {
    final cleanName = name.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '_');
    return '${id}_$cleanName';
  }

  // --- LOCAL SESSION KEYS ---
  static const String _keyUserId = "session_user_id";
  static const String _keyUserRole = "session_user_role";

  // --- LOCAL MEMORY DB (OFFLINE FALLBACK) ---
  final Map<String, UserModel> _mockUsers = {};
  final Map<String, AddressModel> _mockAddresses = {}; // format: "userId_addressId" -> Address
  final Map<String, RestaurantModel> _mockRestaurants = {};
  final Map<String, DeliveryPartnerModel> _mockDeliveryPartners = {};
  final Map<String, FoodItemModel> _mockFoodItems = {};
  final Map<String, OrderModel> _mockOrders = {};
  final Map<String, PostModel> _mockPosts = {};
  final Map<String, Map<String, bool>> _mockLikes = {}; // postId -> userId -> bool
  final Map<String, List<CommentModel>> _mockComments = {}; // postId -> comments
  final Map<String, List<NotificationModel>> _mockNotifications = {}; // userId -> notifications
  final Map<String, Map<String, bool>> _mockSavedPosts = {}; // userId -> postId -> bool
  final Map<String, Map<String, bool>> _mockReports = {}; // postId -> userId -> bool
  final Map<String, Map<String, bool>> _mockUserReports = {}; // userId -> postId -> bool
  final Map<String, Map<String, bool>> _mockFollowing = {}; // userId -> targetId -> bool
  final Map<String, Map<String, bool>> _mockFollowers = {}; // targetId -> userId -> bool

  UserModel? _mockCurrentUser;

  // Real-time broadcast controllers
  final _restaurantsController = StreamController<List<RestaurantModel>>.broadcast();
  final _deliveryPartnersController = StreamController<List<DeliveryPartnerModel>>.broadcast();
  final _foodItemsController = StreamController<List<FoodItemModel>>.broadcast();
  final _ordersController = StreamController<List<OrderModel>>.broadcast();
  final _postsController = StreamController<List<PostModel>>.broadcast();
  final _notificationsController = StreamController<List<NotificationModel>>.broadcast();
  final _addressesController = StreamController<List<AddressModel>>.broadcast();

  // --- SESSION PERSISTENCE ---
  String? _fallbackUserId;
  UserRole? _fallbackUserRole;
  bool _useSharedPreferences = true;

  Future<SharedPreferences?> _getPrefs() async {
    if (!_useSharedPreferences) return null;
    try {
      final prefs = await SharedPreferences.getInstance().timeout(
        const Duration(seconds: 1),
      );
      return prefs;
    } catch (e) {
      _useSharedPreferences = false;
      print("SharedPreferences not available, using in-memory fallback.");
      return null;
    }
  }

  Future<void> saveSession(String userId, UserRole role) async {
    _fallbackUserId = userId;
    _fallbackUserRole = role;
    try {
      final prefs = await _getPrefs();
      if (prefs != null) {
        await prefs.setString(_keyUserId, userId);
        await prefs.setString(_keyUserRole, role.name);
      }
    } catch (e) {
      print("SharedPreferences fallback active: $e");
    }
  }

  Future<void> clearSession() async {
    _fallbackUserId = null;
    _fallbackUserRole = null;
    _mockCurrentUser = null;
    try {
      if (isFirebaseAvailable) {
        await FirebaseAuth.instance.signOut();
      }
      final prefs = await _getPrefs();
      if (prefs != null) {
        await prefs.remove(_keyUserId);
        await prefs.remove(_keyUserRole);
      }
    } catch (e) {
      print("SharedPreferences fallback active: $e");
    }
  }

  Future<String?> getSessionUserId() async {
    try {
      final prefs = await _getPrefs();
      if (prefs != null) {
        return prefs.getString(_keyUserId) ?? _fallbackUserId;
      }
      return _fallbackUserId;
    } catch (e) {
      return _fallbackUserId;
    }
  }

  Future<UserRole?> getSessionUserRole() async {
    try {
      final prefs = await _getPrefs();
      if (prefs != null) {
        final roleStr = prefs.getString(_keyUserRole);
        if (roleStr == null) return _fallbackUserRole;
        return UserRole.values.firstWhere((e) => e.name == roleStr, orElse: () => UserRole.customer);
      }
      return _fallbackUserRole;
    } catch (e) {
      return _fallbackUserRole;
    }
  }

  // --- FIREBASE AUTHENTICATION IMPLEMENTATION ---
  Future<UserModel> signUp({
    required String email,
    required String password,
    required String name,
    required String phone,
    required UserRole role,
    required String securityQuestion,
    required String securityAnswer,
    required String profilePic,
  }) async {
    if (isFirebaseAvailable) {
      final credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      final uid = credential.user!.uid;

      // Assign random locations for simulation purposes around a city center (e.g. Bangalore 12.9716, 77.5946)
      final random = Random();
      final double latOffset = (random.nextDouble() - 0.5) * 0.1; // roughly within 5-10km
      final double lngOffset = (random.nextDouble() - 0.5) * 0.1;
      final double userLat = 12.9716 + latOffset;
      final double userLng = 77.5946 + lngOffset;

      final user = UserModel(
        uid: uid,
        name: name,
        email: email.trim(),
        phone: phone,
        passwordHash: '', // handled by firebase auth now
        securityQuestion: securityQuestion,
        securityAnswer: securityAnswer,
        profilePic: profilePic.isEmpty ? 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=150' : profilePic,
        bio: 'Hello! I am a food enthusiast.',
        role: role,
        latitude: userLat,
        longitude: userLng,
      );

      await FirebaseDatabase.instance.ref('uc/users/$uid').set(user.toJson());

      if (role == UserRole.restaurant) {
        final restaurant = RestaurantModel(
          id: uid,
          name: name,
          description: 'A premium kitchen serving delicious foods.',
          address: 'Main Street, City Center',
          contact: phone,
          profileImage: user.profilePic,
          coverImage: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=600',
          galleryImages: [user.profilePic],
          ownerUid: uid,
          rating: 4.5,
          isVegOnly: false,
          latitude: userLat,
          longitude: userLng,
          activeDeliveryPartners: {},
        );
        await FirebaseDatabase.instance.ref('uc/restaurants/$uid').set(restaurant.toJson());
      } else if (role == UserRole.deliveryPartner) {
        final partner = DeliveryPartnerModel(
          id: uid,
          name: name,
          mobile: phone,
          email: email.trim(),
          address: 'Delivery Zone A',
          bio: 'Fast and reliable delivery partner.',
          photo: user.profilePic,
          rating: 4.8,
          isOnline: true,
          earnings: 0.0,
          latitude: userLat,
          longitude: userLng,
        );
        await FirebaseDatabase.instance.ref('uc/delivery_partners/$uid').set(partner.toJson());
      }

      await saveSession(uid, role);
      return user;
    } else {
      // Mock Fallback
      final uid = 'mock_usr_${DateTime.now().millisecondsSinceEpoch}';
      final user = UserModel(
        uid: uid,
        name: name,
        email: email.trim(),
        phone: phone,
        passwordHash: 'mock_password_hash',
        securityQuestion: securityQuestion,
        securityAnswer: securityAnswer,
        profilePic: profilePic.isEmpty ? 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=150' : profilePic,
        bio: 'Foodie developer.',
        role: role,
        latitude: 12.9716,
        longitude: 77.5946,
      );

      _mockUsers[uid] = user;
      _mockCurrentUser = user;

      if (role == UserRole.restaurant) {
        _mockRestaurants[uid] = RestaurantModel(
          id: uid,
          name: name,
          description: 'A premium mock restaurant.',
          address: 'Main Street, City Center',
          contact: phone,
          profileImage: user.profilePic,
          coverImage: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=600',
          galleryImages: [user.profilePic],
          ownerUid: uid,
          rating: 4.3,
          isVegOnly: false,
          latitude: 12.9716,
          longitude: 77.5946,
          activeDeliveryPartners: {},
        );
      } else if (role == UserRole.deliveryPartner) {
        _mockDeliveryPartners[uid] = DeliveryPartnerModel(
          id: uid,
          name: name,
          mobile: phone,
          email: email.trim(),
          address: 'Mock Delivery Hub',
          bio: 'Quick rider.',
          photo: user.profilePic,
          rating: 4.7,
          isOnline: true,
          earnings: 0.0,
          latitude: 12.9716,
          longitude: 77.5946,
        );
      }

      await saveSession(uid, role);
      return user;
    }
  }

  Future<UserModel> signIn({required String email, required String password}) async {
    if (isFirebaseAvailable) {
      final credential = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      final uid = credential.user!.uid;
      final profile = await _getUserProfileByUid(uid);
      if (profile == null) {
        await FirebaseAuth.instance.signOut();
        throw Exception('USER_NOT_FOUND: Profile not found in Realtime Database.');
      }
      await saveSession(uid, profile.role);
      return profile;
    } else {
      // Offline fallback lookup
      UserModel? found;
      for (var u in _mockUsers.values) {
        if (u.email.toLowerCase() == email.toLowerCase()) {
          found = u;
          break;
        }
      }
      if (found != null) {
        _mockCurrentUser = found;
        await saveSession(found.uid, found.role);
        return found;
      }
      throw Exception('Invalid email or password.');
    }
  }

  Future<UserModel?> getCurrentUser() async {
    final sessionUid = await getSessionUserId();
    if (isFirebaseAvailable) {
      final authUser = FirebaseAuth.instance.currentUser;
      if (authUser == null) return null;
      return _getUserProfileByUid(authUser.uid);
    } else {
      if (sessionUid == null) return null;
      _mockCurrentUser = _mockUsers[sessionUid];
      return _mockCurrentUser;
    }
  }

  Future<void> resetPassword({required String email, required String securityAnswer, required String newPassword}) async {
    if (isFirebaseAvailable) {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email.trim());
    } else {
      UserModel? found;
      for (var u in _mockUsers.values) {
        if (u.email.toLowerCase() == email.toLowerCase()) {
          found = u;
          break;
        }
      }
      if (found != null && found.securityAnswer.toLowerCase().trim() == securityAnswer.toLowerCase().trim()) {
        return;
      }
      throw Exception('Security answer verification failed.');
    }
  }

  Future<void> updateUserProfile(UserModel user) async {
    if (isFirebaseAvailable) {
      await FirebaseDatabase.instance.ref('uc/users/${user.uid}').update(user.toJson());
      if (user.role == UserRole.restaurant) {
        await FirebaseDatabase.instance.ref('uc/restaurants/${user.uid}').update({
          'name': user.name,
          'contact': user.phone,
          'profileImage': user.profilePic,
        });
      } else if (user.role == UserRole.deliveryPartner) {
        await FirebaseDatabase.instance.ref('uc/delivery_partners/${user.uid}').update({
          'name': user.name,
          'mobile': user.phone,
          'photo': user.profilePic,
        });
      }
    } else {
      _mockUsers[user.uid] = user;
      if (_mockCurrentUser?.uid == user.uid) {
        _mockCurrentUser = user;
      }
      if (user.role == UserRole.restaurant && _mockRestaurants.containsKey(user.uid)) {
        _mockRestaurants[user.uid] = _mockRestaurants[user.uid]!.copyWith(
          name: user.name,
          contact: user.phone,
          profileImage: user.profilePic,
        );
      } else if (user.role == UserRole.deliveryPartner && _mockDeliveryPartners.containsKey(user.uid)) {
        _mockDeliveryPartners[user.uid] = _mockDeliveryPartners[user.uid]!.copyWith(
          name: user.name,
          mobile: user.phone,
          photo: user.profilePic,
        );
      }
    }
  }

  // --- ADDRESSES API ---
  Stream<List<AddressModel>> getAddressesStream(String userId) {
    if (isFirebaseAvailable) {
      return FirebaseDatabase.instance.ref('uc/addresses/$userId').onValue.map((event) {
        final Map<dynamic, dynamic>? data = event.snapshot.value as Map?;
        if (data == null) return [];
        return data.entries.map((e) => AddressModel.fromJson(e.value as Map, e.key.toString())).toList();
      });
    } else {
      final list = _mockAddresses.entries
          .where((e) => e.key.startsWith('${userId}_'))
          .map((e) => e.value)
          .toList();
      scheduleMicrotask(() => _addressesController.add(list));
      return _addressesController.stream;
    }
  }

  Future<void> addAddress(String userId, AddressModel address) async {
    if (isFirebaseAvailable) {
      final ref = FirebaseDatabase.instance.ref('uc/addresses/$userId').push();
      final newAddress = AddressModel(
        id: ref.key!,
        title: address.title,
        addressLine: address.addressLine,
        phone: address.phone,
        latitude: address.latitude,
        longitude: address.longitude,
      );
      await ref.set(newAddress.toJson());
    } else {
      final id = 'addr_${DateTime.now().millisecondsSinceEpoch}';
      final newAddress = AddressModel(
        id: id,
        title: address.title,
        addressLine: address.addressLine,
        phone: address.phone,
        latitude: 12.9716,
        longitude: 77.5946,
      );
      _mockAddresses['${userId}_$id'] = newAddress;
      
      final list = _mockAddresses.entries
          .where((e) => e.key.startsWith('${userId}_'))
          .map((e) => e.value)
          .toList();
      _addressesController.add(list);
    }
  }

  // --- RESTAURANTS API ---
  Stream<List<RestaurantModel>> getRestaurantsStream() {
    if (isFirebaseAvailable) {
      return FirebaseDatabase.instance.ref('uc/restaurants').onValue.map((event) {
        final Map<dynamic, dynamic>? data = event.snapshot.value as Map?;
        if (data == null) return [];
        return data.entries.map((e) => RestaurantModel.fromJson(e.value as Map, e.key.toString())).toList();
      });
    } else {
      scheduleMicrotask(() => _restaurantsController.add(_mockRestaurants.values.toList()));
      return _restaurantsController.stream;
    }
  }

  Future<void> updateRestaurant(RestaurantModel restaurant) async {
    if (isFirebaseAvailable) {
      await FirebaseDatabase.instance.ref('uc/restaurants/${restaurant.id}').update(restaurant.toJson());
    } else {
      _mockRestaurants[restaurant.id] = restaurant;
      _restaurantsController.add(_mockRestaurants.values.toList());
    }
  }

  // --- DELIVERY PARTNERS API ---
  Stream<List<DeliveryPartnerModel>> getDeliveryPartnersStream() {
    if (isFirebaseAvailable) {
      return FirebaseDatabase.instance.ref('uc/delivery_partners').onValue.map((event) {
        final Map<dynamic, dynamic>? data = event.snapshot.value as Map?;
        if (data == null) return [];
        return data.entries.map((e) => DeliveryPartnerModel.fromJson(e.value as Map, e.key.toString())).toList();
      });
    } else {
      scheduleMicrotask(() => _deliveryPartnersController.add(_mockDeliveryPartners.values.toList()));
      return _deliveryPartnersController.stream;
    }
  }

  Future<void> updateDeliveryPartner(DeliveryPartnerModel partner) async {
    if (isFirebaseAvailable) {
      await FirebaseDatabase.instance.ref('uc/delivery_partners/${partner.id}').update(partner.toJson());
    } else {
      _mockDeliveryPartners[partner.id] = partner;
      _deliveryPartnersController.add(_mockDeliveryPartners.values.toList());
    }
  }

  // --- FOOD ITEMS API ---
  Stream<List<FoodItemModel>> getFoodItemsStream() {
    if (isFirebaseAvailable) {
      return FirebaseDatabase.instance.ref('uc/menu').onValue.map((event) {
        final Map<dynamic, dynamic>? data = event.snapshot.value as Map?;
        if (data == null) return [];
        return data.entries.map((e) => FoodItemModel.fromJson(e.value as Map, e.key.toString())).toList();
      });
    } else {
      scheduleMicrotask(() => _foodItemsController.add(_mockFoodItems.values.toList()));
      return _foodItemsController.stream;
    }
  }

  Future<void> addFoodItem(FoodItemModel item) async {
    if (isFirebaseAvailable) {
      final ref = FirebaseDatabase.instance.ref('uc/menu').push();
      final key = _buildPathKey(ref.key!, item.name);
      final newItem = FoodItemModel(
        id: key,
        restaurantId: item.restaurantId,
        name: item.name,
        description: item.description,
        price: item.price,
        discount: item.discount,
        image: item.image,
        isVeg: item.isVeg,
        isAvailable: item.isAvailable,
        preparationTime: item.preparationTime,
      );
      await FirebaseDatabase.instance.ref('uc/menu/$key').set(newItem.toJson());
    } else {
      final rawId = 'food_${DateTime.now().millisecondsSinceEpoch}';
      final key = _buildPathKey(rawId, item.name);
      final newItem = FoodItemModel(
        id: key,
        restaurantId: item.restaurantId,
        name: item.name,
        description: item.description,
        price: item.price,
        discount: item.discount,
        image: item.image,
        isVeg: item.isVeg,
        isAvailable: item.isAvailable,
        preparationTime: item.preparationTime,
      );
      _mockFoodItems[key] = newItem;
      _foodItemsController.add(_mockFoodItems.values.toList());
    }
  }

  Future<void> updateFoodItem(FoodItemModel item) async {
    if (isFirebaseAvailable) {
      await FirebaseDatabase.instance.ref('uc/menu/${item.id}').update(item.toJson());
    } else {
      _mockFoodItems[item.id] = item;
      _foodItemsController.add(_mockFoodItems.values.toList());
    }
  }

  // --- ORDERS API ---
  Stream<List<OrderModel>> getOrdersStream(String id, UserRole role) {
    if (isFirebaseAvailable) {
      var query = FirebaseDatabase.instance.ref('uc/orders');
      if (role == UserRole.customer) {
        return query.orderByChild('customerId').equalTo(id).onValue.map((event) {
          final Map<dynamic, dynamic>? data = event.snapshot.value as Map?;
          if (data == null) return [];
          return data.entries.map((e) => OrderModel.fromJson(e.value as Map, e.key.toString())).toList()
            ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
        });
      } else if (role == UserRole.restaurant) {
        return query.orderByChild('restaurantId').equalTo(id).onValue.map((event) {
          final Map<dynamic, dynamic>? data = event.snapshot.value as Map?;
          if (data == null) return [];
          return data.entries.map((e) => OrderModel.fromJson(e.value as Map, e.key.toString())).toList()
            ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
        });
      } else {
        return query.orderByChild('deliveryPartnerId').equalTo(id).onValue.map((event) {
          final Map<dynamic, dynamic>? data = event.snapshot.value as Map?;
          if (data == null) return [];
          return data.entries.map((e) => OrderModel.fromJson(e.value as Map, e.key.toString())).toList()
            ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
        });
      }
    } else {
      List<OrderModel> list = [];
      if (role == UserRole.customer) {
        list = _mockOrders.values.where((o) => o.customerId == id).toList();
      } else if (role == UserRole.restaurant) {
        list = _mockOrders.values.where((o) => o.restaurantId == id).toList();
      } else {
        list = _mockOrders.values.where((o) => o.deliveryPartnerId == id).toList();
      }
      list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      scheduleMicrotask(() => _ordersController.add(list));
      return _ordersController.stream;
    }
  }

  Future<String> createOrder(OrderModel order) async {
    if (isFirebaseAvailable) {
      final ref = FirebaseDatabase.instance.ref('uc/orders').push();
      final id = ref.key!;
      final newOrder = order.copyWith(id: id);
      await ref.set(newOrder.toJson());
      return id;
    } else {
      final id = 'order_${DateTime.now().millisecondsSinceEpoch}';
      final newOrder = order.copyWith(id: id);
      _mockOrders[id] = newOrder;
      
      final sessionUid = await getSessionUserId();
      final sessionRole = await getSessionUserRole();
      if (sessionUid != null && sessionRole != null) {
        List<OrderModel> list = [];
        if (sessionRole == UserRole.customer) {
          list = _mockOrders.values.where((o) => o.customerId == sessionUid).toList();
        } else if (sessionRole == UserRole.restaurant) {
          list = _mockOrders.values.where((o) => o.restaurantId == sessionUid).toList();
        } else {
          list = _mockOrders.values.where((o) => o.deliveryPartnerId == sessionUid).toList();
        }
        list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
        _ordersController.add(list);
      }
      return id;
    }
  }

  Future<void> updateOrder(OrderModel order) async {
    if (isFirebaseAvailable) {
      await FirebaseDatabase.instance.ref('uc/orders/${order.id}').update(order.toJson());
    } else {
      _mockOrders[order.id] = order;
      final sessionUid = await getSessionUserId();
      final sessionRole = await getSessionUserRole();
      if (sessionUid != null && sessionRole != null) {
        List<OrderModel> list = [];
        if (sessionRole == UserRole.customer) {
          list = _mockOrders.values.where((o) => o.customerId == sessionUid).toList();
        } else if (sessionRole == UserRole.restaurant) {
          list = _mockOrders.values.where((o) => o.restaurantId == sessionUid).toList();
        } else {
          list = _mockOrders.values.where((o) => o.deliveryPartnerId == sessionUid).toList();
        }
        list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
        _ordersController.add(list);
      }
    }
  }

  // --- SOCIAL FEED API ---
  Stream<List<PostModel>> getPostsStream() {
    if (isFirebaseAvailable) {
      return FirebaseDatabase.instance.ref('uc/posts').onValue.map((event) {
        final Map<dynamic, dynamic>? data = event.snapshot.value as Map?;
        if (data == null) return [];
        return data.entries.map((e) => PostModel.fromJson(e.value as Map, e.key.toString())).toList()
          ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
      });
    } else {
      scheduleMicrotask(() => _postsController.add(_mockPosts.values.toList()
        ..sort((a, b) => b.timestamp.compareTo(a.timestamp))));
      return _postsController.stream;
    }
  }

  Future<void> createPost(PostModel post) async {
    if (isFirebaseAvailable) {
      final ref = FirebaseDatabase.instance.ref('uc/posts').push();
      final newPost = post.copyWith(id: ref.key!);
      await ref.set(newPost.toJson());
    } else {
      final id = 'post_${DateTime.now().millisecondsSinceEpoch}';
      final newPost = post.copyWith(id: id);
      _mockPosts[id] = newPost;
      _postsController.add(_mockPosts.values.toList()
        ..sort((a, b) => b.timestamp.compareTo(a.timestamp)));
    }
  }

  // --- LIKES API ---
  Future<void> toggleLike(String postId, String userId) async {
    if (isFirebaseAvailable) {
      final ref = FirebaseDatabase.instance.ref('uc/likes/$postId/$userId');
      final snapshot = await ref.get();
      if (snapshot.exists) {
        await ref.remove();
      } else {
        await ref.set(true);
      }
    } else {
      final postLikes = _mockLikes[postId] ?? {};
      if (postLikes[userId] == true) {
        postLikes.remove(userId);
      } else {
        postLikes[userId] = true;
      }
      _mockLikes[postId] = postLikes;
    }
  }

  Future<int> getLikesCount(String postId) async {
    if (isFirebaseAvailable) {
      final snapshot = await FirebaseDatabase.instance.ref('uc/likes/$postId').get();
      if (snapshot.exists && snapshot.value is Map) {
        return (snapshot.value as Map).length;
      }
      return 0;
    } else {
      return (_mockLikes[postId] ?? {}).length;
    }
  }

  Future<bool> hasLiked(String postId, String userId) async {
    if (isFirebaseAvailable) {
      final snapshot = await FirebaseDatabase.instance.ref('uc/likes/$postId/$userId').get();
      return snapshot.exists;
    } else {
      return (_mockLikes[postId] ?? {})[userId] == true;
    }
  }

  // --- COMMENTS API ---
  Future<List<CommentModel>> getComments(String postId) async {
    if (isFirebaseAvailable) {
      final snapshot = await FirebaseDatabase.instance.ref('uc/comments/$postId').get();
      if (snapshot.exists && snapshot.value is Map) {
        final data = snapshot.value as Map;
        return data.entries.map((e) => CommentModel.fromJson(e.value as Map, e.key.toString())).toList();
      }
      return [];
    } else {
      return _mockComments[postId] ?? [];
    }
  }

  Future<void> addComment(CommentModel comment) async {
    if (isFirebaseAvailable) {
      final ref = FirebaseDatabase.instance.ref('uc/comments/${comment.postId}').push();
      final newComment = comment.copyWith(id: ref.key!);
      await ref.set(newComment.toJson());
    } else {
      final id = 'comment_${DateTime.now().millisecondsSinceEpoch}';
      final newComment = comment.copyWith(id: id);
      final list = _mockComments[comment.postId] ?? [];
      list.add(newComment);
      _mockComments[comment.postId] = list;
    }
  }

  // --- NOTIFICATIONS API ---
  Stream<List<NotificationModel>> getNotificationsStream(String userId) {
    if (isFirebaseAvailable) {
      return FirebaseDatabase.instance.ref('uc/notifications/$userId').onValue.map((event) {
        final Map<dynamic, dynamic>? data = event.snapshot.value as Map?;
        if (data == null) return [];
        return data.entries.map((e) => NotificationModel.fromJson(e.value as Map, e.key.toString())).toList()
          ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
      });
    } else {
      final list = _mockNotifications[userId] ?? [];
      list.sort((a, b) => b.timestamp.compareTo(a.timestamp));
      scheduleMicrotask(() => _notificationsController.add(list));
      return _notificationsController.stream;
    }
  }

  Future<void> createNotification(String userId, String title, String body, String type) async {
    final notification = NotificationModel(
      id: '',
      title: title,
      body: body,
      type: type,
      read: false,
      timestamp: DateTime.now().millisecondsSinceEpoch,
    );

    if (isFirebaseAvailable) {
      final ref = FirebaseDatabase.instance.ref('uc/notifications/$userId').push();
      await ref.set(notification.toJson());
    } else {
      final id = 'notif_${DateTime.now().millisecondsSinceEpoch}';
      final newNot = notification.copyWith(id: id);
      final list = _mockNotifications[userId] ?? [];
      list.add(newNot);
      _mockNotifications[userId] = list;
      _notificationsController.add(list);
    }
  }

  Future<void> markNotificationsRead(String userId) async {
    if (isFirebaseAvailable) {
      final ref = FirebaseDatabase.instance.ref('uc/notifications/$userId');
      final snapshot = await ref.get();
      if (snapshot.exists && snapshot.value is Map) {
        final data = snapshot.value as Map;
        for (var key in data.keys) {
          await ref.child('$key/read').set(true);
        }
      }
    } else {
      final list = _mockNotifications[userId] ?? [];
      final updated = list.map((n) => n.copyWith(read: true)).toList();
      _mockNotifications[userId] = updated;
      _notificationsController.add(updated);
    }
  }

  // --- SAVED POSTS API ---
  Future<void> toggleBookmark(String userId, String postId) async {
    if (isFirebaseAvailable) {
      final ref = FirebaseDatabase.instance.ref('uc/saved_posts/$userId/$postId');
      final snapshot = await ref.get();
      if (snapshot.exists) {
        await ref.remove();
      } else {
        await ref.set(true);
      }
    } else {
      final userSaved = _mockSavedPosts[userId] ?? {};
      if (userSaved[postId] == true) {
        userSaved.remove(postId);
      } else {
        userSaved[postId] = true;
      }
      _mockSavedPosts[userId] = userSaved;
    }
  }

  Future<bool> isBookmarked(String userId, String postId) async {
    if (isFirebaseAvailable) {
      final snapshot = await FirebaseDatabase.instance.ref('uc/saved_posts/$userId/$postId').get();
      return snapshot.exists;
    } else {
      return (_mockSavedPosts[userId] ?? {})[postId] == true;
    }
  }

  Future<List<String>> getSavedPostIds(String userId) async {
    if (isFirebaseAvailable) {
      final snapshot = await FirebaseDatabase.instance.ref('uc/saved_posts/$userId').get();
      if (snapshot.exists && snapshot.value is Map) {
        final data = snapshot.value as Map;
        return data.keys.map((k) => k.toString()).toList();
      }
      return [];
    } else {
      return (_mockSavedPosts[userId] ?? {}).keys.toList();
    }
  }

  // --- REPORTS API ---
  Future<void> reportPost(String userId, String postId) async {
    if (isFirebaseAvailable) {
      await FirebaseDatabase.instance.ref('uc/reports/$postId/$userId').set(true);
      await FirebaseDatabase.instance.ref('uc/user_reports/$userId/$postId').set(true);
    } else {
      final reports = _mockReports[postId] ?? {};
      reports[userId] = true;
      _mockReports[postId] = reports;

      final userReports = _mockUserReports[userId] ?? {};
      userReports[postId] = true;
      _mockUserReports[userId] = userReports;
    }
  }

  Future<List<String>> getReportedPostIds(String userId) async {
    if (isFirebaseAvailable) {
      final snapshot = await FirebaseDatabase.instance.ref('uc/user_reports/$userId').get();
      if (snapshot.exists && snapshot.value is Map) {
        final data = snapshot.value as Map;
        return data.keys.map((k) => k.toString()).toList();
      }
      return [];
    } else {
      return (_mockUserReports[userId] ?? {}).keys.toList();
    }
  }

  // --- FOLLOW SYSTEM ---
  Future<void> toggleFollow(String userId, String targetId) async {
    if (isFirebaseAvailable) {
      final followingRef = FirebaseDatabase.instance.ref('uc/following/$userId/$targetId');
      final followerRef = FirebaseDatabase.instance.ref('uc/followers/$targetId/$userId');
      final snapshot = await followingRef.get();
      if (snapshot.exists) {
        await followingRef.remove();
        await followerRef.remove();
      } else {
        await followingRef.set(true);
        await followerRef.set(true);
      }
    } else {
      final userFollowing = _mockFollowing[userId] ?? {};
      final targetFollowers = _mockFollowers[targetId] ?? {};
      if (userFollowing[targetId] == true) {
        userFollowing.remove(targetId);
        targetFollowers.remove(userId);
      } else {
        userFollowing[targetId] = true;
        targetFollowers[userId] = true;
      }
      _mockFollowing[userId] = userFollowing;
      _mockFollowers[targetId] = targetFollowers;
    }
  }

  Future<bool> isFollowing(String userId, String targetId) async {
    if (isFirebaseAvailable) {
      final snapshot = await FirebaseDatabase.instance.ref('uc/following/$userId/$targetId').get();
      return snapshot.exists;
    } else {
      return (_mockFollowing[userId] ?? {})[targetId] == true;
    }
  }

  Future<List<String>> getFollowingIds(String userId) async {
    if (isFirebaseAvailable) {
      final snapshot = await FirebaseDatabase.instance.ref('uc/following/$userId').get();
      if (snapshot.exists && snapshot.value is Map) {
        return (snapshot.value as Map).keys.map((k) => k.toString()).toList();
      }
      return [];
    } else {
      return (_mockFollowing[userId] ?? {}).keys.toList();
    }
  }

  // --- RESTAURANT GALLERY UPLOAD ---
  Future<void> addRestaurantGalleryImage(String restaurantId, String imageUrl) async {
    if (isFirebaseAvailable) {
      final ref = FirebaseDatabase.instance.ref('uc/restaurants/$restaurantId');
      final snapshot = await ref.get();
      if (snapshot.exists && snapshot.value is Map) {
        final data = Map<dynamic, dynamic>.from(snapshot.value as Map);
        final List gallery = List.from(data['galleryImages'] ?? []);
        gallery.add(imageUrl);
        await ref.child('galleryImages').set(gallery);
      }
    } else {
      final restaurant = _mockRestaurants[restaurantId];
      if (restaurant != null) {
        final updatedGallery = List<String>.from(restaurant.galleryImages)..add(imageUrl);
        _mockRestaurants[restaurantId] = restaurant.copyWith(galleryImages: updatedGallery);
        _restaurantsController.add(_mockRestaurants.values.toList());
      }
    }
  }

  Future<UserModel?> _getUserProfileByUid(String uid) async {
    final snapshot = await FirebaseDatabase.instance.ref('uc/users/$uid').get();
    if (!snapshot.exists || snapshot.value == null) return null;
    final value = snapshot.value;
    if (value is Map) {
      return UserModel.fromJson(value, uid);
    }
    return null;
  }

  // --- SEED SYSTEM METADATA ---
  Future<bool> isDatabaseSeeded() async {
    if (isFirebaseAvailable) {
      final snapshot = await FirebaseDatabase.instance.ref('uc/system/seeded').get();
      return snapshot.value == true;
    } else {
      return true; // prevent seeding offline
    }
  }

  Future<void> setDatabaseSeeded() async {
    if (isFirebaseAvailable) {
      await FirebaseDatabase.instance.ref('uc/system/seeded').set(true);
    }
  }

  void seedOfflineMockData() {
    if (_mockUsers.isNotEmpty) return;
    // Basic setup for offline testing empty containers
  }
}
