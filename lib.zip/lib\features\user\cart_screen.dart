import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme.dart';
import '../../core/services/app_provider.dart';
import 'checkout_screen.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final TextEditingController _instructionController = TextEditingController();

  @override
  void dispose() {
    _instructionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = Provider.of<AppProvider>(context);

    // Bill Calculations
    final double itemTotal = app.cartTotal;
    final double taxFee = app.taxAmount;
    final double deliveryFee = app.deliveryFee;
    final double grandTotal = app.grandTotal;

    // Resolve restaurant name from cart if not empty
    String restaurantName = "Restaurant";
    if (app.cart.isNotEmpty) {
      final restId = app.cart.first.foodItem.restaurantId;
      try {
        restaurantName = app.restaurants.firstWhere((r) => r.id == restId).name;
      } catch (_) {}
    }

    return Scaffold(
      backgroundColor: FoodTheme.background,
      appBar: AppBar(
        title: const Text(
          'My Cart',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: FoodTheme.textDark),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        iconTheme: const IconThemeData(color: FoodTheme.textDark),
      ),
      body: app.cart.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(32.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: FoodTheme.primary.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.shopping_bag_outlined,
                        size: 64,
                        color: FoodTheme.primary,
                      ),
                    ),
                    const SizedBox(height: 24),
                    const Text(
                      'Your cart is empty',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: FoodTheme.textDark),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Browse nearby restaurants and add delicious food to your cart.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 13, color: FoodTheme.textLight),
                    ),
                    const SizedBox(height: 32),
                    ElevatedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: FoodTheme.primary,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                        padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 16),
                      ),
                      child: const Text('EXPLORE RESTAURANTS', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white)),
                    ),
                  ],
                ),
              ),
            )
          : Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Restaurant header card
                        Card(
                          color: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                            side: BorderSide(color: Colors.grey.shade200),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Row(
                              children: [
                                const Icon(Icons.restaurant, color: FoodTheme.primary),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        restaurantName,
                                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: FoodTheme.textDark),
                                      ),
                                      const Text(
                                        'Delivering to your selected location',
                                        style: TextStyle(fontSize: 11, color: FoodTheme.textLight),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Selected Items Section
                        const Text(
                          'Items in Cart',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: FoodTheme.textDark),
                        ),
                        const SizedBox(height: 10),
                        Card(
                          color: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                            side: BorderSide(color: Colors.grey.shade200),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: ListView.separated(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemCount: app.cart.length,
                              separatorBuilder: (context, index) => Divider(height: 1, color: Colors.grey.shade100),
                              itemBuilder: (context, index) {
                                final s = app.cart[index];
                                final originalPrice = s.foodItem.price;
                                final discountedPrice = originalPrice - (originalPrice * (s.foodItem.discount / 100));

                                return ListTile(
                                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                  title: Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(3),
                                        decoration: BoxDecoration(
                                          border: Border.all(
                                            color: s.foodItem.isVeg ? Colors.green : Colors.red,
                                            width: 1,
                                          ),
                                          borderRadius: BorderRadius.circular(4),
                                        ),
                                        child: Container(
                                          width: 6,
                                          height: 6,
                                          decoration: BoxDecoration(
                                            color: s.foodItem.isVeg ? Colors.green : Colors.red,
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Text(
                                          s.foodItem.name,
                                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: FoodTheme.textDark),
                                        ),
                                      ),
                                    ],
                                  ),
                                  subtitle: Padding(
                                    padding: const EdgeInsets.only(left: 20.0, top: 4),
                                    child: Text(
                                      '₹${discountedPrice.toStringAsFixed(0)} each',
                                      style: const TextStyle(color: FoodTheme.textLight, fontSize: 11),
                                    ),
                                  ),
                                  trailing: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        '₹${(discountedPrice * s.quantity).toStringAsFixed(0)}',
                                        style: const TextStyle(color: FoodTheme.textDark, fontWeight: FontWeight.bold, fontSize: 13),
                                      ),
                                      const SizedBox(width: 16),
                                      Container(
                                        height: 30,
                                        width: 80,
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(15),
                                          border: Border.all(color: FoodTheme.primary, width: 1.5),
                                        ),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            InkWell(
                                              onTap: () => app.decrementQuantity(s),
                                              child: const Padding(
                                                padding: EdgeInsets.symmetric(horizontal: 8),
                                                child: Icon(Icons.remove, size: 12, color: FoodTheme.primary),
                                              ),
                                            ),
                                            Text(
                                              '${s.quantity}',
                                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: FoodTheme.primary),
                                            ),
                                            InkWell(
                                              onTap: () => app.incrementQuantity(s),
                                              child: const Padding(
                                                padding: EdgeInsets.symmetric(horizontal: 8),
                                                child: Icon(Icons.add, size: 12, color: FoodTheme.primary),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),

                        // Special Instructions
                        const Text(
                          'Cooking / Delivery Instructions',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: FoodTheme.textDark),
                        ),
                        const SizedBox(height: 10),
                        TextField(
                          controller: _instructionController,
                          maxLines: 2,
                          decoration: InputDecoration(
                            hintText: 'Avoid onions, make it spicy, leave at door, etc.',
                            hintStyle: const TextStyle(fontSize: 12, color: FoodTheme.textLight),
                            fillColor: Colors.white,
                            filled: true,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16),
                              borderSide: BorderSide(color: Colors.grey.shade200),
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),

                        // Bill Details Card
                        const Text(
                          'Bill Details',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: FoodTheme.textDark),
                        ),
                        const SizedBox(height: 10),
                        Card(
                          color: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                            side: BorderSide(color: Colors.grey.shade200),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text('Item Total', style: TextStyle(fontSize: 12, color: FoodTheme.textLight)),
                                    Text('₹${itemTotal.toStringAsFixed(2)}', style: const TextStyle(fontSize: 12, color: FoodTheme.textDark, fontWeight: FontWeight.w500)),
                                  ],
                                ),
                                const SizedBox(height: 10),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text('GST & Restaurant Taxes (5%)', style: TextStyle(fontSize: 12, color: FoodTheme.textLight)),
                                    Text('₹${taxFee.toStringAsFixed(2)}', style: const TextStyle(fontSize: 12, color: FoodTheme.textDark, fontWeight: FontWeight.w500)),
                                  ],
                                ),
                                const SizedBox(height: 10),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text('Delivery Partner Fee', style: TextStyle(fontSize: 12, color: FoodTheme.textLight)),
                                    Text('₹${deliveryFee.toStringAsFixed(2)}', style: const TextStyle(fontSize: 12, color: FoodTheme.textDark, fontWeight: FontWeight.w500)),
                                  ],
                                ),
                                const Divider(height: 24, thickness: 0.8),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text('Grand Total', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: FoodTheme.textDark)),
                                    Text('₹${grandTotal.toStringAsFixed(2)}', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: FoodTheme.primary)),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Food safety disclaimer
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4.0),
                          child: Row(
                            children: const [
                              Icon(Icons.check_circle_outline, color: Colors.green, size: 16),
                              SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  '100% safe and hygienic delivery practices followed.',
                                  style: TextStyle(fontSize: 11, color: FoodTheme.textLight),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Sticky Bottom Bar
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, -4)),
                    ],
                  ),
                  child: SafeArea(
                    top: false,
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('₹${grandTotal.toStringAsFixed(2)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: FoodTheme.textDark)),
                              const Text('Grand Total', style: TextStyle(fontSize: 10, color: FoodTheme.textLight, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => CheckoutScreen(
                                    instructions: _instructionController.text.trim(),
                                  ),
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: FoodTheme.primary,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                              padding: const EdgeInsets.symmetric(vertical: 14),
                            ),
                            child: const Text(
                              'PROCEED TO CHECKOUT',
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.white, letterSpacing: 0.5),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}


