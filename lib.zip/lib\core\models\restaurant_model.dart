class RestaurantModel {
  final String id;
  final String name;
  final String description;
  final String address;
  final String contact;
  final String profileImage; // Logo
  final String coverImage;
  final List<String> galleryImages;
  final String ownerUid;
  final double rating;
  final bool isVegOnly;
  final double latitude;
  final double longitude;
  final Map<String, String> activeDeliveryPartners; // partnerId -> status (pending, accepted, rejected)

  RestaurantModel({
    required this.id,
    required this.name,
    required this.description,
    required this.address,
    required this.contact,
    required this.profileImage,
    required this.coverImage,
    required this.galleryImages,
    required this.ownerUid,
    this.rating = 4.0,
    this.isVegOnly = false,
    this.latitude = 0.0,
    this.longitude = 0.0,
    required this.activeDeliveryPartners,
  });

  factory RestaurantModel.fromJson(Map<dynamic, dynamic> json, String id) {
    var partners = json['activeDeliveryPartners'] ?? json['activePriests'];
    Map<String, String> partnerMap = {};
    if (partners is Map) {
      partners.forEach((k, v) {
        partnerMap[k.toString()] = v.toString();
      });
    }

    var gallery = json['galleryImages'];
    List<String> galleryList = [];
    if (gallery is List) {
      galleryList = gallery.map((e) => e.toString()).toList();
    }

    return RestaurantModel(
      id: id,
      name: json['name']?.toString() ?? '',
      description: json['description']?.toString() ?? '',
      address: json['address']?.toString() ?? '',
      contact: json['contact']?.toString() ?? '',
      profileImage: json['profileImage']?.toString() ?? '',
      coverImage: json['coverImage']?.toString() ?? '',
      galleryImages: galleryList,
      ownerUid: json['ownerUid']?.toString() ?? '',
      rating: double.tryParse(json['rating']?.toString() ?? '4.0') ?? 4.0,
      isVegOnly: json['isVegOnly'] == true,
      latitude: double.tryParse(json['latitude']?.toString() ?? '0.0') ?? 0.0,
      longitude: double.tryParse(json['longitude']?.toString() ?? '0.0') ?? 0.0,
      activeDeliveryPartners: partnerMap,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'description': description,
      'address': address,
      'contact': contact,
      'profileImage': profileImage,
      'coverImage': coverImage,
      'galleryImages': galleryImages,
      'ownerUid': ownerUid,
      'rating': rating,
      'isVegOnly': isVegOnly,
      'latitude': latitude,
      'longitude': longitude,
      'activeDeliveryPartners': activeDeliveryPartners,
    };
  }

  RestaurantModel copyWith({
    String? id,
    String? name,
    String? description,
    String? address,
    String? contact,
    String? profileImage,
    String? coverImage,
    List<String>? galleryImages,
    String? ownerUid,
    double? rating,
    bool? isVegOnly,
    double? latitude,
    double? longitude,
    Map<String, String>? activeDeliveryPartners,
  }) {
    return RestaurantModel(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      address: address ?? this.address,
      contact: contact ?? this.contact,
      profileImage: profileImage ?? this.profileImage,
      coverImage: coverImage ?? this.coverImage,
      galleryImages: galleryImages ?? this.galleryImages,
      ownerUid: ownerUid ?? this.ownerUid,
      rating: rating ?? this.rating,
      isVegOnly: isVegOnly ?? this.isVegOnly,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      activeDeliveryPartners: activeDeliveryPartners ?? this.activeDeliveryPartners,
    );
  }
}
