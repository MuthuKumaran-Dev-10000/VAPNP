import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme.dart';
import '../../core/services/auth_provider.dart';
import '../../core/services/app_provider.dart';
import '../../core/models/address_model.dart';
import '../../widgets/offline_banner.dart';

class AddFamilyMemberScreen extends StatefulWidget {
  const AddFamilyMemberScreen({super.key});

  @override
  State<AddFamilyMemberScreen> createState() => _AddFamilyMemberScreenState();
}

class _AddFamilyMemberScreenState extends State<AddFamilyMemberScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _addressController = TextEditingController();
  final _phoneController = TextEditingController();
  
  bool _isSaving = false;

  @override
  void dispose() {
    _titleController.dispose();
    _addressController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  void _saveAddress() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isSaving = true;
    });

    final auth = Provider.of<AuthProvider>(context, listen: false);
    final app = Provider.of<AppProvider>(context, listen: false);

    final String userId = auth.currentUser?.uid ?? '';
    if (userId.isEmpty) return;

    final newAddress = AddressModel(
      id: 'addr_${DateTime.now().millisecondsSinceEpoch}',
      title: _titleController.text.trim(),
      addressLine: _addressController.text.trim(),
      phone: _phoneController.text.trim(),
      latitude: 12.9716, // Default city center coordinates
      longitude: 77.5946,
    );

    try {
      await app.addAddress(userId, newAddress);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Address added successfully!'), backgroundColor: Colors.green),
        );
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to add address: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isSaving = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FoodTheme.background,
      appBar: AppBar(
        title: const Text('Add Address', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: SafeArea(
        child: Column(
          children: [
            const OfflineBanner(),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'New Delivery Location',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: FoodTheme.textDark),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Specify address details for your food deliveries.',
                        style: TextStyle(color: FoodTheme.textLight, fontSize: 13),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 28),
                      TextFormField(
                        controller: _titleController,
                        style: const TextStyle(fontSize: 14),
                        decoration: const InputDecoration(
                          labelText: 'Address Title (e.g. Home, Work, Gym)',
                          prefixIcon: Icon(Icons.bookmark_outline, color: FoodTheme.primary),
                        ),
                        validator: (v) => v == null || v.trim().isEmpty ? 'Enter address title' : null,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _addressController,
                        style: const TextStyle(fontSize: 14),
                        decoration: const InputDecoration(
                          labelText: 'Complete Address Details',
                          prefixIcon: Icon(Icons.location_on_outlined, color: FoodTheme.primary),
                        ),
                        maxLines: 3,
                        validator: (v) => v == null || v.trim().isEmpty ? 'Enter address details' : null,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _phoneController,
                        style: const TextStyle(fontSize: 14),
                        decoration: const InputDecoration(
                          labelText: 'Delivery Contact Phone',
                          prefixIcon: Icon(Icons.phone_outlined, color: FoodTheme.primary),
                        ),
                        keyboardType: TextInputType.phone,
                        validator: (v) => v == null || v.length < 10 ? 'Enter valid phone number' : null,
                      ),
                      const SizedBox(height: 32),

                      _isSaving
                          ? const Center(child: CircularProgressIndicator(color: FoodTheme.primary))
                          : ElevatedButton(
                              onPressed: _saveAddress,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: FoodTheme.primary,
                                padding: const EdgeInsets.symmetric(vertical: 16),
                                elevation: 4,
                                shadowColor: FoodTheme.primary.withOpacity(0.3),
                              ),
                              child: const Text('ADD ADDRESS', style: TextStyle(fontWeight: FontWeight.bold)),
                            ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
