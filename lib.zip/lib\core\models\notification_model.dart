class NotificationModel {
  final String id;
  final String title;
  final String body;
  final String type; // booking_created, booking_accepted, priest_assigned, invitation_received, payment_success, live_session
  final bool read;
  final int timestamp;

  NotificationModel({
    required this.id,
    required this.title,
    required this.body,
    required this.type,
    required this.read,
    required this.timestamp,
  });

  factory NotificationModel.fromJson(Map<dynamic, dynamic> json, String id) {
    return NotificationModel(
      id: id,
      title: json['title']?.toString() ?? '',
      body: json['body']?.toString() ?? '',
      type: json['type']?.toString() ?? 'booking_created',
      read: json['read'] == true,
      timestamp: int.tryParse(json['timestamp']?.toString() ?? '0') ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'body': body,
      'type': type,
      'read': read,
      'timestamp': timestamp,
    };
  }

  NotificationModel copyWith({
    String? id,
    String? title,
    String? body,
    String? type,
    bool? read,
    int? timestamp,
  }) {
    return NotificationModel(
      id: id ?? this.id,
      title: title ?? this.title,
      body: body ?? this.body,
      type: type ?? this.type,
      read: read ?? this.read,
      timestamp: timestamp ?? this.timestamp,
    );
  }
}
