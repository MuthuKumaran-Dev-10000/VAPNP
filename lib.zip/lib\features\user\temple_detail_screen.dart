import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme.dart';
import '../../core/models/restaurant_model.dart';
import '../../core/models/food_item_model.dart';
import '../../core/models/post_model.dart';
import '../../core/services/app_provider.dart';
import '../../core/services/auth_provider.dart';
import 'cart_screen.dart';

class TempleDetailScreen extends StatefulWidget {
  final RestaurantModel temple; // keep parameter name for compat
  const TempleDetailScreen({super.key, required this.temple});

  @override
  State<TempleDetailScreen> createState() => _TempleDetailScreenState();
}

class _TempleDetailScreenState extends State<TempleDetailScreen> {
  bool _isVegFilter = false;
  String _selectedMenuCategory = 'All';

  @override
  Widget build(BuildContext context) {
    final app = Provider.of<AppProvider>(context);
    final auth = Provider.of<AuthProvider>(context);
    final currentUserId = auth.currentUser?.uid ?? '';

    // Re-resolve active restaurant details from state stream lists
    RestaurantModel rest = widget.temple;
    try {
      rest = app.restaurants.firstWhere((r) => r.id == widget.temple.id);
    } catch (_) {}

    // Filter food items belonging to this restaurant
    final restaurantFoodItems = app.foodItems.where((item) {
      final matchesRest = item.restaurantId == rest.id;
      final matchesVeg = !_isVegFilter || item.isVeg;
      return matchesRest && matchesVeg;
    }).toList();

    // Group items into categories
    final categories = ['All'];
    for (var item in restaurantFoodItems) {
      final cat = item.description.contains('Starter')
          ? 'Starters'
          : (item.description.contains('Drink') || item.description.contains('Shake') ? 'Beverages' : 'Main Course');
      if (!categories.contains(cat)) {
        categories.add(cat);
      }
    }

    final displayedFoodItems = restaurantFoodItems.where((item) {
      if (_selectedMenuCategory == 'All') return true;
      final cat = item.description.contains('Starter')
          ? 'Starters'
          : (item.description.contains('Drink') || item.description.contains('Shake') ? 'Beverages' : 'Main Course');
      return cat == _selectedMenuCategory;
    }).toList();

    final restPosts = app.posts.where((p) => p.authorId == rest.id).toList();

    return Scaffold(
      backgroundColor: FoodTheme.background,
      body: DefaultTabController(
        length: 3,
        child: NestedScrollView(
          headerSliverBuilder: (context, innerBoxIsScrolled) {
            return [
              SliverAppBar(
                expandedHeight: 250,
                pinned: true,
                backgroundColor: FoodTheme.primary,
                actions: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.shopping_bag_outlined, color: Colors.white),
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => const CartScreen()),
                          );
                        },
                      ),
                      if (app.cart.isNotEmpty)
                        Positioned(
                          right: 6,
                          top: 6,
                          child: CircleAvatar(
                            radius: 8,
                            backgroundColor: FoodTheme.secondary,
                            child: Text(
                              '${app.cart.length}',
                              style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
                flexibleSpace: FlexibleSpaceBar(
                  background: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.network(
                        rest.coverImage.isNotEmpty ? rest.coverImage : 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=600',
                        fit: BoxFit.cover,
                      ),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.black.withOpacity(0.4), Colors.transparent],
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: FoodTheme.softShadow,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                              radius: 26,
                              backgroundImage: NetworkImage(rest.profileImage),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    rest.name,
                                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: FoodTheme.textDark),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    rest.description,
                                    style: const TextStyle(fontSize: 12, color: FoodTheme.textLight),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(color: Colors.green, borderRadius: BorderRadius.circular(6)),
                              child: Row(
                                children: [
                                  Text('${rest.rating}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                                  const SizedBox(width: 2),
                                  const Icon(Icons.star, color: Colors.white, size: 12),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const Divider(height: 24),
                        Row(
                          children: [
                            const Icon(Icons.location_on, color: FoodTheme.secondary, size: 16),
                            const SizedBox(width: 4),
                            Expanded(
                              child: Text(
                                rest.address,
                                style: const TextStyle(fontSize: 12, color: FoodTheme.textDark),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            // Follow System
                            FutureBuilder<bool>(
                              future: app.isFollowing(currentUserId, rest.id),
                              builder: (context, snapshot) {
                                final isFollowing = snapshot.data ?? false;
                                return ElevatedButton.icon(
                                  onPressed: () async {
                                    await app.toggleFollow(currentUserId, rest.id);
                                  },
                                  icon: Icon(isFollowing ? Icons.check : Icons.add, size: 16),
                                  label: Text(isFollowing ? 'Following' : 'Follow'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: isFollowing ? Colors.grey.shade300 : FoodTheme.primary,
                                    foregroundColor: isFollowing ? FoodTheme.textDark : Colors.white,
                                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                    visualDensity: VisualDensity.compact,
                                  ),
                                );
                              },
                            ),
                            const Spacer(),
                            Row(
                              children: [
                                const Icon(Icons.people_outline, size: 16, color: FoodTheme.textLight),
                                const SizedBox(width: 4),
                                const Text('1.2K Followers', style: TextStyle(fontSize: 12, color: FoodTheme.textLight)),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SliverPositionedPeripheralHeader(),
            ];
          },
          body: Column(
            children: [
              const TabBar(
                labelColor: FoodTheme.primary,
                unselectedLabelColor: FoodTheme.textLight,
                indicatorColor: FoodTheme.primary,
                tabs: [
                  Tab(text: 'Menu'),
                  Tab(text: 'Posts'),
                  Tab(text: 'Gallery'),
                ],
              ),
              Expanded(
                child: TabBarView(
                  children: [
                    // Tab 1: Menu
                    _buildMenuTab(context, app, displayedFoodItems, categories),
                    // Tab 2: Posts
                    _buildPostsTab(context, restPosts),
                    // Tab 3: Gallery
                    _buildGalleryTab(context, rest.galleryImages),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMenuTab(BuildContext context, AppProvider app, List<FoodItemModel> items, List<String> categories) {
    return Column(
      children: [
        // Categories horizontal filter chips + Veg filter toggle
        Container(
          color: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: categories.map((cat) {
                      final isSelected = _selectedMenuCategory == cat;
                      return Padding(
                        padding: const EdgeInsets.only(right: 8.0),
                        child: ChoiceChip(
                          label: Text(cat),
                          selected: isSelected,
                          onSelected: (val) {
                            if (val) setState(() => _selectedMenuCategory = cat);
                          },
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
              const VerticalDivider(width: 16),
              ChoiceChip(
                label: const Text('Veg Only'),
                selected: _isVegFilter,
                onSelected: (val) => setState(() => _isVegFilter = val),
                selectedColor: Colors.green.withOpacity(0.15),
              ),
            ],
          ),
        ),
        
        // Menu list
        Expanded(
          child: items.isEmpty
              ? const Center(child: Text('No food items found.', style: TextStyle(color: FoodTheme.textLight)))
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: items.length,
                  itemBuilder: (context, index) {
                    final item = items[index];
                    final cartQty = app.getQuantity(item);

                    return Card(
                      color: Colors.white,
                      margin: const EdgeInsets.only(bottom: 16),
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                        side: BorderSide(color: Colors.grey.shade100),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.network(
                                item.image,
                                width: 80,
                                height: 80,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Container(width: 80, height: 80, color: FoodTheme.primary.withOpacity(0.1)),
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(
                                        item.isVeg ? Icons.circle : Icons.circle,
                                        color: item.isVeg ? Colors.green : Colors.red,
                                        size: 14,
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        item.name,
                                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: FoodTheme.textDark),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    item.description,
                                    style: const TextStyle(fontSize: 11, color: FoodTheme.textLight),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 8),
                                  Row(
                                    children: [
                                      Text(
                                        '₹${item.price.toStringAsFixed(0)}',
                                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: FoodTheme.textDark),
                                      ),
                                      if (item.discount > 0) ...[
                                        const SizedBox(width: 6),
                                        Text(
                                          '₹${(item.price + (item.price * item.discount / 100)).toStringAsFixed(0)}',
                                          style: const TextStyle(fontSize: 11, decoration: TextDecoration.lineThrough, color: FoodTheme.textLight),
                                        ),
                                        const SizedBox(width: 6),
                                        Text(
                                          '${item.discount.toStringAsFixed(0)}% OFF',
                                          style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: FoodTheme.secondary),
                                        ),
                                      ],
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            // Swiggy style add button
                            cartQty > 0
                                ? Container(
                                    height: 32,
                                    decoration: BoxDecoration(
                                      color: FoodTheme.primary,
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        IconButton(
                                          icon: const Icon(Icons.remove, size: 12, color: Colors.white),
                                          onPressed: () {
                                            final cartItem = app.cart.firstWhere((i) => i.foodItem.id == item.id);
                                            app.decrementQuantity(cartItem);
                                          },
                                        ),
                                        Text('$cartQty', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                                        IconButton(
                                          icon: const Icon(Icons.add, size: 12, color: Colors.white),
                                          onPressed: () {
                                            final cartItem = app.cart.firstWhere((i) => i.foodItem.id == item.id);
                                            app.incrementQuantity(cartItem);
                                          },
                                        ),
                                      ],
                                    ),
                                  )
                                : ElevatedButton(
                                    onPressed: () {
                                      app.addToCart(item);
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                          content: Text('Added ${item.name} to cart!'),
                                          backgroundColor: FoodTheme.primary,
                                          duration: const Duration(seconds: 1),
                                        ),
                                      );
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.white,
                                      foregroundColor: FoodTheme.primary,
                                      side: const BorderSide(color: FoodTheme.primary, width: 1.5),
                                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                      visualDensity: VisualDensity.compact,
                                    ),
                                    child: const Text('ADD', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                                  ),
                          ],
                        ),
                      ),
                    );
                  },
                  ),
        ),
      ],
    );
  }

  Widget _buildPostsTab(BuildContext context, List<PostModel> posts) {
    if (posts.isEmpty) {
      return const Center(child: Text('No updates posted yet.', style: TextStyle(color: FoodTheme.textLight)));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: posts.length,
      itemBuilder: (context, index) {
        final p = posts[index];
        return Card(
          color: Colors.white,
          margin: const EdgeInsets.only(bottom: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.network(p.imageUrl, height: 180, width: double.infinity, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox()),
              Padding(
                padding: const EdgeInsets.all(12.0),
                child: Text(p.caption, style: const TextStyle(fontSize: 13)),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildGalleryTab(BuildContext context, List<String> images) {
    if (images.isEmpty) {
      return const Center(child: Text('No gallery photos found.', style: TextStyle(color: FoodTheme.textLight)));
    }
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: images.length,
      itemBuilder: (context, index) {
        return ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.network(images[index], fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: Colors.grey.shade200)),
        );
      },
    );
  }
}

class SliverPositionedPeripheralHeader extends StatelessWidget {
  const SliverPositionedPeripheralHeader({super.key});

  @override
  Widget build(BuildContext context) {
    return const SliverToBoxAdapter(child: SizedBox.shrink());
  }
}
