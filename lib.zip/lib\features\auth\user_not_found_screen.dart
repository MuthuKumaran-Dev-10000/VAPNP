import 'package:flutter/material.dart';
import '../../core/theme.dart';
import 'login_screen.dart';
import 'signup_screen.dart';

class UserNotFoundScreen extends StatelessWidget {
  final String email;

  const UserNotFoundScreen({
    super.key,
    required this.email,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FoodTheme.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline_rounded, size: 72, color: FoodTheme.secondary),
                  const SizedBox(height: 18),
                  const Text(
                    'Profile Not Found',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: FoodTheme.textDark),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 10),
                  Text(
                    email.isEmpty
                        ? 'We could not find a database profile for this account.'
                        : 'The account $email signed in, but its profile is missing from the database.',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: FoodTheme.textLight, fontSize: 13, height: 1.5),
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).pushReplacement(
                          MaterialPageRoute(builder: (_) => const SignupScreen()),
                        );
                      },
                      style: ElevatedButton.styleFrom(backgroundColor: FoodTheme.primary),
                      child: const Text('CREATE NEW PROFILE'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (_) => const LoginScreen()),
                      );
                    },
                    child: const Text('BACK TO LOGIN', style: TextStyle(color: FoodTheme.primary, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
