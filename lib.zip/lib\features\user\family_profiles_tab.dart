import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme.dart';
import '../../core/models/address_model.dart';
import '../../core/services/app_provider.dart';
import '../../core/services/auth_provider.dart';
import 'add_family_member_screen.dart';

class FamilyProfilesTab extends StatefulWidget {
  const FamilyProfilesTab({super.key});

  @override
  State<FamilyProfilesTab> createState() => _FamilyProfilesTabState();
}

class _FamilyProfilesTabState extends State<FamilyProfilesTab> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final auth = Provider.of<AuthProvider>(context, listen: false);
      final app = Provider.of<AppProvider>(context, listen: false);
      if (auth.currentUser != null) {
        app.listenUserSessions(auth.currentUser!.uid, auth.currentUser!.role);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final app = Provider.of<AppProvider>(context);

    if (auth.currentUser == null) return const SizedBox.shrink();

    return Scaffold(
      backgroundColor: FoodTheme.background,
      body: app.addresses.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(32.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.location_off_outlined, size: 64, color: FoodTheme.textLight.withOpacity(0.5)),
                    const SizedBox(height: 16),
                    const Text(
                      'No saved addresses yet',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: FoodTheme.textDark),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Add your delivery addresses for seamless checkouts.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12, color: FoodTheme.textLight),
                    ),
                  ],
                ),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: app.addresses.length,
              itemBuilder: (context, index) {
                final addr = app.addresses[index];
                final isHome = addr.title.toLowerCase() == 'home';
                final isWork = addr.title.toLowerCase() == 'work';
                
                IconData leadingIcon = Icons.location_on_outlined;
                if (isHome) leadingIcon = Icons.home_outlined;
                if (isWork) leadingIcon = Icons.work_outline;

                return Card(
                  color: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  elevation: 0,
                  margin: const EdgeInsets.only(bottom: 12),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.grey.shade100),
                    ),
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CircleAvatar(
                          radius: 20,
                          backgroundColor: FoodTheme.primary.withOpacity(0.1),
                          child: Icon(leadingIcon, color: FoodTheme.primary, size: 20),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                addr.title,
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: FoodTheme.textDark),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                addr.addressLine,
                                style: const TextStyle(fontSize: 13, color: FoodTheme.textDark, height: 1.4),
                              ),
                              const SizedBox(height: 6),
                              Row(
                                children: [
                                  const Icon(Icons.phone_outlined, size: 12, color: FoodTheme.textLight),
                                  const SizedBox(width: 4),
                                  Text(
                                    addr.phone,
                                    style: const TextStyle(fontSize: 11, color: FoodTheme.textLight),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: FoodTheme.primary,
        foregroundColor: Colors.white,
        elevation: 4,
        icon: const Icon(Icons.add_location_alt_outlined),
        label: const Text('Add Address', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const AddFamilyMemberScreen()),
          );
        },
      ),
    );
  }
}
