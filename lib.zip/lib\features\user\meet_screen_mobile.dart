import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme.dart';
import '../../core/services/app_provider.dart';
import '../../core/models/order_model.dart';
import '../../widgets/offline_banner.dart';

Widget getInAppMeetScreen(String orderId) => MobileMeetScreen(orderId: orderId);

class MobileMeetScreen extends StatelessWidget {
  final String orderId;
  const MobileMeetScreen({super.key, required this.orderId});

  @override
  Widget build(BuildContext context) {
    final app = Provider.of<AppProvider>(context);
    OrderModel? order;
    try {
      order = app.orders.firstWhere((o) => o.id == orderId);
    } catch (_) {}

    if (order == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Track Order')),
        body: const Center(child: Text('Order not found.')),
      );
    }

    final double partnerLat = order.latitude;
    final double partnerLng = order.longitude;

    // Define timeline steps
    final steps = ['placed', 'accepted', 'preparing', 'picked_up', 'on_the_way', 'delivered', 'completed'];
    final stepLabels = {
      'placed': 'Order Placed',
      'accepted': 'Accepted by Kitchen',
      'preparing': 'Preparing Food',
      'picked_up': 'Picked Up',
      'on_the_way': 'On The Way',
      'delivered': 'Arrived at Location',
      'completed': 'Completed',
    };

    final currentIdx = steps.indexOf(order.status);

    return Scaffold(
      backgroundColor: FoodTheme.background,
      appBar: AppBar(
        title: const Text('Live Order Tracking', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: Column(
        children: [
          const OfflineBanner(),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Restaurant Header
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: FoodTheme.softShadow,
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: FoodTheme.primary.withOpacity(0.1),
                          child: const Icon(Icons.restaurant, color: FoodTheme.primary),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                order.restaurantName,
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: FoodTheme.textDark),
                              ),
                              Text(
                                'Order Total: ₹${order.amount.toStringAsFixed(0)}',
                                style: const TextStyle(fontSize: 12, color: FoodTheme.textLight),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.green.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            order.paymentStatus.toUpperCase(),
                            style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 10),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Premium Map view Placeholder
                  Container(
                    height: 220,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: Colors.blue.shade100, width: 2),
                      boxShadow: FoodTheme.softShadow,
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        // Map lines grid simulation
                        Positioned.fill(
                          child: Opacity(
                            opacity: 0.1,
                            child: GridPaper(
                              color: Colors.blue.shade900,
                              interval: 30,
                              divisions: 2,
                            ),
                          ),
                        ),
                        // Restaurant pin
                        Positioned(
                          left: 60,
                          top: 50,
                          child: Column(
                            children: [
                              const Icon(Icons.restaurant, color: FoodTheme.secondary, size: 28),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(4)),
                                child: Text(order.restaurantName, style: const TextStyle(fontSize: 8, fontWeight: FontWeight.bold)),
                              ),
                            ],
                          ),
                        ),
                        // Customer Address pin
                        Positioned(
                          right: 60,
                          bottom: 50,
                          child: Column(
                            children: [
                              const Icon(Icons.home, color: Colors.blue, size: 28),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(4)),
                                child: const Text('Your Location', style: TextStyle(fontSize: 8, fontWeight: FontWeight.bold)),
                              ),
                            ],
                          ),
                        ),
                        // Delivery partner pin (moves closer based on status)
                        if (order.status != 'placed' && order.status != 'accepted')
                          AnimatedPositioned(
                            duration: const Duration(seconds: 1),
                            left: currentIdx >= 4 ? 180 : 100,
                            top: currentIdx >= 4 ? 120 : 80,
                            child: Column(
                              children: [
                                const Icon(Icons.delivery_dining, color: FoodTheme.primary, size: 36),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(4)),
                                  child: const Text('Rider En Route', style: TextStyle(fontSize: 8, fontWeight: FontWeight.bold, color: FoodTheme.primary)),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Delivery Partner Details Card
                  if (order.deliveryPartnerId.isNotEmpty)
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: FoodTheme.softShadow,
                      ),
                      child: Row(
                        children: [
                          const CircleAvatar(
                            backgroundColor: FoodTheme.primary,
                            child: Icon(Icons.person, color: Colors.white),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  order.deliveryPartnerName,
                                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: FoodTheme.textDark),
                                ),
                                const Text(
                                  'Delivery Executive matched',
                                  style: TextStyle(fontSize: 11, color: FoodTheme.textLight),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.phone, color: Colors.green),
                            onPressed: () {},
                          ),
                        ],
                      ),
                    ),
                  const SizedBox(height: 24),

                  // Order Timeline Track
                  const Text('Delivery Progress', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: FoodTheme.textDark)),
                  const SizedBox(height: 16),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: steps.length,
                    itemBuilder: (context, index) {
                      final stepKey = steps[index];
                      final label = stepLabels[stepKey]!;
                      
                      final isPassed = index <= currentIdx;
                      final isCurrent = index == currentIdx;

                      return Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            children: [
                              Container(
                                width: 24,
                                height: 24,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: isPassed ? FoodTheme.primary : Colors.grey.shade300,
                                  border: isCurrent ? Border.all(color: FoodTheme.secondary, width: 2.5) : null,
                                ),
                                child: isPassed
                                    ? const Icon(Icons.check, size: 14, color: Colors.white)
                                    : null,
                              ),
                              if (index < steps.length - 1)
                                Container(
                                  width: 2,
                                  height: 36,
                                  color: index < currentIdx ? FoodTheme.primary : Colors.grey.shade300,
                                ),
                            ],
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(top: 2.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    label,
                                    style: TextStyle(
                                      fontWeight: isPassed ? FontWeight.bold : FontWeight.normal,
                                      fontSize: 13.5,
                                      color: isPassed ? FoodTheme.textDark : FoodTheme.textLight,
                                    ),
                                  ),
                                  if (isCurrent)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 4.0),
                                      child: Text(
                                        'Active Step',
                                        style: TextStyle(color: FoodTheme.secondary, fontSize: 10, fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
