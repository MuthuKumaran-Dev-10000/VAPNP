class AddressModel {
  final String id;
  final String title; // e.g. "Home", "Work"
  final String addressLine;
  final String phone;
  final double latitude;
  final double longitude;

  AddressModel({
    required this.id,
    required this.title,
    required this.addressLine,
    required this.phone,
    this.latitude = 0.0,
    this.longitude = 0.0,
  });

  factory AddressModel.fromJson(Map<dynamic, dynamic> json, String id) {
    return AddressModel(
      id: id,
      title: (json['title'] ?? json['relationship'] ?? 'Home').toString(),
      addressLine: (json['addressLine'] ?? json['name'] ?? '').toString(),
      phone: (json['phone'] ?? json['dob'] ?? '').toString(),
      latitude: double.tryParse(json['latitude']?.toString() ?? '0.0') ?? 0.0,
      longitude: double.tryParse(json['longitude']?.toString() ?? '0.0') ?? 0.0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'addressLine': addressLine,
      'phone': phone,
      'latitude': latitude,
      'longitude': longitude,
    };
  }

  AddressModel copyWith({
    String? id,
    String? title,
    String? addressLine,
    String? phone,
    double? latitude,
    double? longitude,
  }) {
    return AddressModel(
      id: id ?? this.id,
      title: title ?? this.title,
      addressLine: addressLine ?? this.addressLine,
      phone: phone ?? this.phone,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
    );
  }
}
