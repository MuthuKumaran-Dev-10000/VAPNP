import 'food_item_model.dart';
export 'food_item_model.dart';
typedef ServiceModel = FoodItemModel;
