import 'food_item_model.dart';

class CartItem {
  final FoodItemModel foodItem;
  int quantity;
  String instructions;

  CartItem({
    required this.foodItem,
    this.quantity = 1,
    this.instructions = '',
  });

  Map<String, dynamic> toJson() {
    return {
      'foodItem': foodItem.toJson(),
      'quantity': quantity,
      'instructions': instructions,
    };
  }

  factory CartItem.fromJson(Map<dynamic, dynamic> json) {
    return CartItem(
      foodItem: FoodItemModel.fromJson(json['foodItem'] ?? {}, json['foodItem']?['id']?.toString() ?? ''),
      quantity: int.tryParse(json['quantity']?.toString() ?? '1') ?? 1,
      instructions: json['instructions']?.toString() ?? '',
    );
  }
}
