import 'cart_item.dart';

class OrderModel {
  final String id;
  final String customerId;
  final String customerName;
  final String restaurantId;
  final String restaurantName;
  final String deliveryPartnerId;
  final String deliveryPartnerName;
  final List<CartItem> items;
  final double amount;
  final String status; // placed, accepted, preparing, picked_up, on_the_way, delivered, completed, cancelled
  final String paymentMethod; // razorpay, cod
  final String paymentStatus; // pending, success, failed
  final String paymentReference;
  final int createdAt;
  final String deliveryAddress;
  final String deliveryInstructions;
  final double latitude; // Delivery partner live lat
  final double longitude; // Delivery partner live lng

  // Compatibility Getters for legacy references
  String get serviceId => items.isNotEmpty ? items.first.foodItem.id : '';
  String get serviceName => items.isNotEmpty ? items.first.foodItem.name : 'Food Order';
  String get bookingDate => deliveryAddress;
  String get bookingTime => deliveryInstructions;
  String get assignedPriest => deliveryPartnerId;
  String get assignedPriestName => deliveryPartnerName;
  String get userId => customerId;
  String get userName => customerName;
  String get templeId => restaurantId;
  String get templeName => restaurantName;
  String get jitsiLink => ''; // No longer used, stubbed to prevent compile errors
  List<String> get participants => const []; // legacy field stubbed

  OrderModel({
    required this.id,
    required this.customerId,
    required this.customerName,
    required this.restaurantId,
    required this.restaurantName,
    required this.deliveryPartnerId,
    required this.deliveryPartnerName,
    required this.items,
    required this.amount,
    required this.status,
    required this.paymentMethod,
    required this.paymentStatus,
    required this.paymentReference,
    required this.createdAt,
    required this.deliveryAddress,
    required this.deliveryInstructions,
    this.latitude = 0.0,
    this.longitude = 0.0,
  });

  factory OrderModel.fromJson(Map<dynamic, dynamic> json, String id) {
    var rawItems = json['items'];
    List<CartItem> parsedItems = [];
    if (rawItems is List) {
      parsedItems = rawItems.map((e) => CartItem.fromJson(e as Map)).toList();
    } else if (rawItems is Map) {
      parsedItems = rawItems.values.map((e) => CartItem.fromJson(e as Map)).toList();
    }

    return OrderModel(
      id: id,
      customerId: (json['customerId'] ?? json['userId'] ?? '').toString(),
      customerName: (json['customerName'] ?? json['userName'] ?? '').toString(),
      restaurantId: (json['restaurantId'] ?? json['templeId'] ?? '').toString(),
      restaurantName: (json['restaurantName'] ?? json['templeName'] ?? '').toString(),
      deliveryPartnerId: (json['deliveryPartnerId'] ?? json['priestId'] ?? json['assignedPriest'] ?? '').toString(),
      deliveryPartnerName: (json['deliveryPartnerName'] ?? json['assignedPriestName'] ?? '').toString(),
      items: parsedItems,
      amount: double.tryParse(json['amount']?.toString() ?? '0') ?? 0.0,
      status: json['status']?.toString() ?? 'placed',
      paymentMethod: json['paymentMethod']?.toString() ?? 'cod',
      paymentStatus: json['paymentStatus']?.toString() ?? 'pending',
      paymentReference: json['paymentReference']?.toString() ?? '',
      createdAt: int.tryParse(json['createdAt']?.toString() ?? '0') ?? 0,
      deliveryAddress: (json['deliveryAddress'] ?? json['bookingDate'] ?? '').toString(),
      deliveryInstructions: (json['deliveryInstructions'] ?? json['bookingTime'] ?? '').toString(),
      latitude: double.tryParse(json['latitude']?.toString() ?? '0.0') ?? 0.0,
      longitude: double.tryParse(json['longitude']?.toString() ?? '0.0') ?? 0.0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'customerId': customerId,
      'customerName': customerName,
      'restaurantId': restaurantId,
      'restaurantName': restaurantName,
      'deliveryPartnerId': deliveryPartnerId,
      'deliveryPartnerName': deliveryPartnerName,
      'items': items.map((e) => e.toJson()).toList(),
      'amount': amount,
      'status': status,
      'paymentMethod': paymentMethod,
      'paymentStatus': paymentStatus,
      'paymentReference': paymentReference,
      'createdAt': createdAt,
      'deliveryAddress': deliveryAddress,
      'deliveryInstructions': deliveryInstructions,
      'latitude': latitude,
      'longitude': longitude,
    };
  }

  OrderModel copyWith({
    String? id,
    String? customerId,
    String? customerName,
    String? restaurantId,
    String? restaurantName,
    String? deliveryPartnerId,
    String? deliveryPartnerName,
    List<CartItem>? items,
    double? amount,
    String? status,
    String? paymentMethod,
    String? paymentStatus,
    String? paymentReference,
    int? createdAt,
    String? deliveryAddress,
    String? deliveryInstructions,
    double? latitude,
    double? longitude,
  }) {
    return OrderModel(
      id: id ?? this.id,
      customerId: customerId ?? this.customerId,
      customerName: customerName ?? this.customerName,
      restaurantId: restaurantId ?? this.restaurantId,
      restaurantName: restaurantName ?? this.restaurantName,
      deliveryPartnerId: deliveryPartnerId ?? this.deliveryPartnerId,
      deliveryPartnerName: deliveryPartnerName ?? this.deliveryPartnerName,
      items: items ?? this.items,
      amount: amount ?? this.amount,
      status: status ?? this.status,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      paymentStatus: paymentStatus ?? this.paymentStatus,
      paymentReference: paymentReference ?? this.paymentReference,
      createdAt: createdAt ?? this.createdAt,
      deliveryAddress: deliveryAddress ?? this.deliveryAddress,
      deliveryInstructions: deliveryInstructions ?? this.deliveryInstructions,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
    );
  }
}
