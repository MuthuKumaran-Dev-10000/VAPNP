import 'dart:async';
import 'package:flutter/material.dart';
import '../models/restaurant_model.dart';
import '../models/delivery_partner_model.dart';
import '../models/food_item_model.dart';
import '../models/order_model.dart';
import '../models/address_model.dart';
import '../models/user_model.dart';
import '../models/post_model.dart';
import '../models/comment_model.dart';
import '../models/notification_model.dart';
import '../models/cart_item.dart';
import 'firebase_service.dart';

class AppProvider extends ChangeNotifier {
  final FirebaseService _firebaseService = FirebaseService();
  FirebaseService get firebaseService => _firebaseService;

  // Stream Subscriptions
  StreamSubscription? _restaurantsSub;
  StreamSubscription? _deliveryPartnersSub;
  StreamSubscription? _foodItemsSub;
  StreamSubscription? _ordersSub;
  StreamSubscription? _postsSub;
  StreamSubscription? _addressesSub;
  StreamSubscription? _notifSub;

  List<RestaurantModel> restaurants = [];
  List<DeliveryPartnerModel> deliveryPartners = [];
  List<FoodItemModel> foodItems = [];
  List<OrderModel> orders = [];
  List<PostModel> posts = [];
  List<AddressModel> addresses = [];
  List<NotificationModel> notifications = [];
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  // Shopping Cart
  final List<CartItem> _cart = [];
  List<CartItem> get cart => _cart;
  
  double get cartTotal => _cart.fold(0.0, (sum, item) {
        final price = item.foodItem.price;
        final discount = item.foodItem.discount;
        final finalPrice = price - (price * (discount / 100));
        return sum + (finalPrice * item.quantity);
      });

  double get taxAmount => cartTotal * 0.05; // 5% GST/Tax
  double get deliveryFee => cartTotal > 0 ? 30.0 : 0.0; // Flat ₹30 delivery fee
  double get grandTotal => cartTotal + taxAmount + deliveryFee;

  int getQuantity(FoodItemModel s) {
    try {
      return _cart.firstWhere((item) => item.foodItem.id == s.id).quantity;
    } catch (_) {
      return 0;
    }
  }

  void addToCart(FoodItemModel s, {String instructions = ''}) {
    final idx = _cart.indexWhere((item) => item.foodItem.id == s.id);
    if (idx != -1) {
      _cart[idx].quantity++;
    } else {
      _cart.add(CartItem(foodItem: s, quantity: 1, instructions: instructions));
    }
    notifyListeners();
  }

  void removeFromCart(CartItem item) {
    _cart.removeWhere((i) => i.foodItem.id == item.foodItem.id);
    notifyListeners();
  }

  void incrementQuantity(CartItem item) {
    final idx = _cart.indexWhere((i) => i.foodItem.id == item.foodItem.id);
    if (idx != -1) {
      _cart[idx].quantity++;
      notifyListeners();
    }
  }

  void decrementQuantity(CartItem item) {
    final idx = _cart.indexWhere((i) => i.foodItem.id == item.foodItem.id);
    if (idx != -1) {
      if (_cart[idx].quantity > 1) {
        _cart[idx].quantity--;
      } else {
        _cart.removeAt(idx);
      }
      notifyListeners();
    }
  }

  void removeFromCartByFoodItem(FoodItemModel s) {
    _cart.removeWhere((item) => item.foodItem.id == s.id);
    notifyListeners();
  }

  void clearCart() {
    _cart.clear();
    notifyListeners();
  }

  // --- STREAM LISTENERS ---
  void listenAllGlobalData() {
    _restaurantsSub?.cancel();
    _restaurantsSub = _firebaseService.getRestaurantsStream().listen((list) {
      restaurants = list;
      notifyListeners();
    }, onError: (e) {
      debugPrint("Error listening to restaurants: $e");
    });

    _deliveryPartnersSub?.cancel();
    _deliveryPartnersSub = _firebaseService.getDeliveryPartnersStream().listen((list) {
      deliveryPartners = list;
      notifyListeners();
    }, onError: (e) {
      debugPrint("Error listening to delivery partners: $e");
    });

    _foodItemsSub?.cancel();
    _foodItemsSub = _firebaseService.getFoodItemsStream().listen((list) {
      foodItems = list;
      notifyListeners();
    }, onError: (e) {
      debugPrint("Error listening to food items: $e");
    });

    _postsSub?.cancel();
    _postsSub = _firebaseService.getPostsStream().listen((list) {
      posts = list;
      notifyListeners();
    }, onError: (e) {
      debugPrint("Error listening to posts: $e");
    });
  }

  void listenUserSessions(String userId, UserRole role) {
    _ordersSub?.cancel();
    _ordersSub = _firebaseService.getOrdersStream(userId, role).listen((list) {
      orders = list;
      notifyListeners();
    }, onError: (e) {
      debugPrint("Error listening to orders: $e");
    });

    _notifSub?.cancel();
    _notifSub = _firebaseService.getNotificationsStream(userId).listen((list) {
      notifications = list;
      notifyListeners();
    }, onError: (e) {
      debugPrint("Error listening to notifications: $e");
    });

    if (role == UserRole.customer) {
      _addressesSub?.cancel();
      _addressesSub = _firebaseService.getAddressesStream(userId).listen((list) {
        addresses = list;
        notifyListeners();
      }, onError: (e) {
        debugPrint("Error listening to addresses: $e");
      });
    }
  }

  // --- ADDRESSES CRUD ---
  Future<void> addAddress(String userId, AddressModel address) async {
    await _firebaseService.addAddress(userId, address);
  }

  // --- RESTAURANT CRUD ---
  Future<void> updateRestaurantProfile(RestaurantModel restaurant) async {
    await _firebaseService.updateRestaurant(restaurant);
  }

  // --- DELIVERY PARTNER CRUD ---
  Future<void> updateDeliveryPartnerProfile(DeliveryPartnerModel partner) async {
    await _firebaseService.updateDeliveryPartner(partner);
  }

  // --- FOOD ITEMS CRUD ---
  Future<void> createFoodItem(FoodItemModel item) async {
    await _firebaseService.addFoodItem(item);
  }

  Future<String> checkoutOrder({
    required String customerId,
    required String customerName,
    required String deliveryAddress,
    required String deliveryInstructions,
    required String paymentMethod,
    required String paymentRef,
  }) async {
    if (_cart.isEmpty) return '';

    _isLoading = true;
    notifyListeners();

    // Group items by restaurant if multiple restaurants exist (ideally checkout is per restaurant)
    final firstItem = _cart.first;
    final restaurantId = firstItem.foodItem.restaurantId;
    String resolvedRestName = 'Restaurant';
    try {
      resolvedRestName = restaurants.firstWhere((r) => r.id == restaurantId).name;
    } catch (_) {}

    final order = OrderModel(
      id: '',
      customerId: customerId,
      customerName: customerName,
      restaurantId: restaurantId,
      restaurantName: resolvedRestName,
      deliveryPartnerId: '',
      deliveryPartnerName: '',
      items: List.from(_cart),
      amount: grandTotal,
      status: 'placed',
      paymentMethod: paymentMethod,
      paymentStatus: paymentMethod == 'cod' ? 'pending' : 'success',
      paymentReference: paymentRef,
      createdAt: DateTime.now().millisecondsSinceEpoch,
      deliveryAddress: deliveryAddress,
      deliveryInstructions: deliveryInstructions,
    );

    final generatedId = await _firebaseService.createOrder(order);
    
    // Create notifications for the restaurant
    await _firebaseService.createNotification(
      restaurantId,
      'New Order Received',
      'Order of ₹${grandTotal.toStringAsFixed(0)} placed by customer $customerName.',
      'order_received',
    );

    clearCart();
    _isLoading = false;
    notifyListeners();
    return generatedId;
  }

  Future<void> updateOrderDetails(OrderModel order) async {
    await _firebaseService.updateOrder(order);
  }

  // Automatic delivery matching
  Future<void> searchAndAssignDeliveryPartner(OrderModel order) async {
    // 1. Find restaurant coordinates
    RestaurantModel? rest;
    try {
      rest = restaurants.firstWhere((r) => r.id == order.restaurantId);
    } catch (_) {}

    final restLat = rest?.latitude ?? 12.9716;
    final restLng = rest?.longitude ?? 77.5946;

    // 2. Query online riders
    final onlinePartners = deliveryPartners.where((p) => p.isOnline).toList();

    if (onlinePartners.isEmpty) {
      debugPrint("No online delivery partners found.");
      return;
    }

    // 3. Sort by Haversine distance from the restaurant
    onlinePartners.sort((a, b) {
      final distA = _firebaseService.calculateDistance(restLat, restLng, a.latitude, a.longitude);
      final distB = _firebaseService.calculateDistance(restLat, restLng, b.latitude, b.longitude);
      return distA.compareTo(distB);
    });

    // 4. Send matched request to nearest partner (simulate assignment)
    final matchedPartner = onlinePartners.first;

    // Update order with target partner and status 'placed_matching'
    final matchedOrder = order.copyWith(
      deliveryPartnerId: matchedPartner.id,
      deliveryPartnerName: matchedPartner.name,
      status: 'assigning',
    );

    await _firebaseService.updateOrder(matchedOrder);

    // Send notification to delivery partner
    await _firebaseService.createNotification(
      matchedPartner.id,
      'Incoming Delivery Request',
      'Deliver from ${order.restaurantName} to ${order.customerName}.',
      'delivery_request',
    );
  }

  // --- SOCIAL FEED ---
  Future<void> addSocialPost(PostModel post) async {
    await _firebaseService.createPost(post);
  }

  Future<void> toggleLike(String postId, String userId) async {
    await _firebaseService.toggleLike(postId, userId);
    notifyListeners();
  }

  Future<int> getPostLikes(String postId) async {
    return await _firebaseService.getLikesCount(postId);
  }

  Future<bool> checkUserLiked(String postId, String userId) async {
    return await _firebaseService.hasLiked(postId, userId);
  }

  Future<List<CommentModel>> getComments(String postId) async {
    return await _firebaseService.getComments(postId);
  }

  Future<void> addComment(CommentModel comment) async {
    await _firebaseService.addComment(comment);
    notifyListeners();
  }

  // --- BOOKMARKS & REPORTS ---
  Future<void> toggleBookmark(String userId, String postId) async {
    await _firebaseService.toggleBookmark(userId, postId);
    notifyListeners();
  }

  Future<bool> checkUserBookmarked(String userId, String postId) async {
    return await _firebaseService.isBookmarked(userId, postId);
  }

  Future<List<String>> getSavedPostIds(String userId) async {
    return await _firebaseService.getSavedPostIds(userId);
  }

  Future<void> reportPost(String userId, String postId) async {
    await _firebaseService.reportPost(userId, postId);
    notifyListeners();
  }

  Future<List<String>> getReportedPostIds(String userId) async {
    return await _firebaseService.getReportedPostIds(userId);
  }

  // --- FOLLOW SYSTEM ---
  Future<void> toggleFollow(String userId, String targetId) async {
    await _firebaseService.toggleFollow(userId, targetId);
    notifyListeners();
  }

  Future<bool> isFollowing(String userId, String targetId) async {
    return await _firebaseService.isFollowing(userId, targetId);
  }

  Future<List<String>> getFollowingIds(String userId) async {
    return await _firebaseService.getFollowingIds(userId);
  }

  // --- GALLERY ---
  Future<void> addRestaurantGalleryImage(String restaurantId, String imageUrl) async {
    await _firebaseService.addRestaurantGalleryImage(restaurantId, imageUrl);
    notifyListeners();
  }

  // --- NOTIFICATIONS ---
  Future<void> clearNotifications(String userId) async {
    await _firebaseService.markNotificationsRead(userId);
  }

  @override
  void dispose() {
    _restaurantsSub?.cancel();
    _deliveryPartnersSub?.cancel();
    _foodItemsSub?.cancel();
    _ordersSub?.cancel();
    _postsSub?.cancel();
    _addressesSub?.cancel();
    _notifSub?.cancel();
    super.dispose();
  }
}
