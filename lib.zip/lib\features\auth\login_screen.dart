import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme.dart';
import '../../core/services/auth_provider.dart';
import '../../core/models/user_model.dart';
import 'signup_screen.dart';
import 'forgot_password_screen.dart';
import 'user_not_found_screen.dart';
import '../restaurant/restaurant_dashboard.dart';
import '../delivery_partner/delivery_dashboard.dart';
import '../user/user_home.dart';
import '../../widgets/offline_banner.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  // Autofill config: User requested empty values so they can map their own accounts later.
  static const List<_DemoAccount> _demoAccounts = [
    _DemoAccount(
      label: 'Customer Autofill',
      email: '',
      password: '',
      role: 'customer',
      icon: Icons.person_outline,
    ),
    _DemoAccount(
      label: 'Restaurant Autofill',
      email: '',
      password: '',
      role: 'restaurant',
      icon: Icons.restaurant_menu,
    ),
    _DemoAccount(
      label: 'Partner Autofill',
      email: '',
      password: '',
      role: 'deliveryPartner',
      icon: Icons.delivery_dining,
    ),
  ];

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _login() async {
    if (!_formKey.currentState!.validate()) return;

    final auth = Provider.of<AuthProvider>(context, listen: false);
    final success = await auth.signIn(
      _emailController.text.trim(),
      _passwordController.text.trim(),
    );

    if (success && mounted) {
      final role = auth.currentUser?.role;
      if (role == UserRole.restaurant) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const RestaurantDashboard()),
        );
      } else if (role == UserRole.deliveryPartner) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const DeliveryDashboard()),
        );
      } else {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const UserHome()),
        );
      }
    } else if (mounted && auth.profileMissing) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => UserNotFoundScreen(email: _emailController.text.trim()),
        ),
      );
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(auth.errorMessage ?? 'Authentication failed.'),
          backgroundColor: FoodTheme.secondary,
        ),
      );
    }
  }

  void _fillDemoCredentials(_DemoAccount account) {
    setState(() {
      _emailController.text = account.email;
      _passwordController.text = account.password;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FoodTheme.background,
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            const OfflineBanner(),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    // Premium Header with dynamic orange gradients
                    Container(
                      height: 260,
                      width: double.infinity,
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [FoodTheme.primary, FoodTheme.secondary],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(40),
                          bottomRight: Radius.circular(40),
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.fastfood_rounded,
                            color: Colors.white,
                            size: 72,
                          ),
                          const SizedBox(height: 12),
                          const Text(
                            'QuickBites',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 32,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            'Your favorite meals delivered fast',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.85),
                              fontSize: 14,
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 28),
                    // Demo Autofill Shortcuts card
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24.0),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(24),
                          boxShadow: FoodTheme.softShadow,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Row(
                              children: [
                                Icon(Icons.flash_on, color: FoodTheme.primary, size: 20),
                                SizedBox(width: 8),
                                Text(
                                  'Autofill Account Mappings',
                                  style: TextStyle(
                                    color: FoodTheme.textDark,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: _demoAccounts
                                  .map(
                                    (account) => ActionChip(
                                      avatar: Icon(account.icon, size: 14, color: FoodTheme.primary),
                                      label: Text(account.label, style: const TextStyle(fontSize: 11)),
                                      backgroundColor: FoodTheme.background,
                                      side: BorderSide(color: Colors.grey.shade200),
                                      onPressed: () => _fillDemoCredentials(account),
                                    ),
                                  )
                                  .toList(),
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              'Click to populate the fields with your custom credentials.',
                              style: TextStyle(fontSize: 11, color: FoodTheme.textLight, height: 1.4),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    // Login fields Card
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24.0),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            const Text(
                              'Welcome Back',
                              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: FoodTheme.textDark),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 20),
                            TextFormField(
                              controller: _emailController,
                              style: const TextStyle(fontSize: 14),
                              decoration: const InputDecoration(
                                labelText: 'Email Address',
                                prefixIcon: Icon(Icons.email_outlined, color: FoodTheme.primary),
                              ),
                              keyboardType: TextInputType.emailAddress,
                              validator: (v) {
                                final value = v?.trim() ?? '';
                                if (value.isEmpty) return 'Enter a valid email';
                                return null;
                              },
                            ),
                            const SizedBox(height: 16),
                            TextFormField(
                              controller: _passwordController,
                              style: const TextStyle(fontSize: 14),
                              decoration: const InputDecoration(
                                labelText: 'Password',
                                prefixIcon: Icon(Icons.lock_outline, color: FoodTheme.primary),
                              ),
                              obscureText: true,
                              validator: (v) => v == null || v.length < 6 ? 'Password must be at least 6 characters' : null,
                            ),
                            Align(
                              alignment: Alignment.centerRight,
                              child: TextButton(
                                onPressed: () {
                                  Navigator.of(context).push(
                                    MaterialPageRoute(builder: (_) => const ForgotPasswordScreen()),
                                  );
                                },
                                child: const Text(
                                  'Forgot Password?',
                                  style: TextStyle(color: FoodTheme.primary, fontSize: 13, fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            Consumer<AuthProvider>(
                              builder: (context, auth, _) {
                                return auth.isLoading
                                    ? const Center(child: CircularProgressIndicator(color: FoodTheme.primary))
                                    : ElevatedButton(
                                        onPressed: _login,
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: FoodTheme.primary,
                                          padding: const EdgeInsets.symmetric(vertical: 16),
                                          elevation: 4,
                                          shadowColor: FoodTheme.primary.withOpacity(0.3),
                                        ),
                                        child: const Text('SIGN IN'),
                                      );
                              },
                            ),
                            const SizedBox(height: 24),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Text('New to QuickBites? ', style: TextStyle(color: FoodTheme.textLight)),
                                TextButton(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                      MaterialPageRoute(builder: (_) => const SignupScreen()),
                                    );
                                  },
                                  child: const Text(
                                    'Create Account',
                                    style: TextStyle(
                                      color: FoodTheme.primary,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DemoAccount {
  final String label;
  final String email;
  final String password;
  final String role;
  final IconData icon;

  const _DemoAccount({
    required this.label,
    required this.email,
    required this.password,
    required this.role,
    required this.icon,
  });
}
