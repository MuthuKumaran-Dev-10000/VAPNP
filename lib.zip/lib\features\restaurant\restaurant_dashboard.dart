import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/theme.dart';
import '../../core/services/app_provider.dart';
import '../../core/services/auth_provider.dart';
import '../../core/services/cloudinary_service.dart';
import '../../core/models/food_item_model.dart';
import '../../core/models/order_model.dart';
import '../../core/models/post_model.dart';
import '../../widgets/offline_banner.dart';

class RestaurantDashboard extends StatefulWidget {
  const RestaurantDashboard({super.key});

  @override
  State<RestaurantDashboard> createState() => _RestaurantDashboardState();
}

class _RestaurantDashboardState extends State<RestaurantDashboard> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final auth = Provider.of<AuthProvider>(context, listen: false);
      final app = Provider.of<AppProvider>(context, listen: false);
      app.listenAllGlobalData();
      if (auth.currentUser != null) {
        app.listenUserSessions(auth.currentUser!.uid, auth.currentUser!.role);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final app = Provider.of<AppProvider>(context);

    if (auth.currentUser == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final String restaurantId = auth.currentUser!.uid;

    // Filter orders and food items for this restaurant
    final restaurantOrders = app.orders.where((o) => o.restaurantId == restaurantId).toList();
    final restaurantMenu = app.foodItems.where((item) => item.restaurantId == restaurantId).toList();

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: FoodTheme.background,
        appBar: AppBar(
          title: Text(auth.currentUser!.name, style: const TextStyle(fontWeight: FontWeight.bold, color: FoodTheme.textDark)),
          backgroundColor: Colors.white,
          elevation: 0,
          actions: [
            IconButton(
              icon: const Icon(Icons.logout, color: FoodTheme.secondary),
              onPressed: () async {
                await auth.signOut();
                if (context.mounted) {
                  Navigator.of(context).pushReplacementNamed('/');
                }
              },
            ),
          ],
          bottom: const TabBar(
            labelColor: FoodTheme.primary,
            unselectedLabelColor: FoodTheme.textLight,
            indicatorColor: FoodTheme.primary,
            tabs: [
              Tab(icon: Icon(Icons.analytics_outlined), text: 'Orders'),
              Tab(icon: Icon(Icons.menu_book_outlined), text: 'Menu'),
              Tab(icon: Icon(Icons.campaign_outlined), text: 'Studio'),
            ],
          ),
        ),
        body: Column(
          children: [
            const OfflineBanner(),
            Expanded(
              child: TabBarView(
                children: [
                  _OrdersTab(orders: restaurantOrders, app: app),
                  _MenuTab(menu: restaurantMenu, restaurantId: restaurantId, app: app),
                  _StudioTab(restaurantId: restaurantId, restaurantName: auth.currentUser!.name, restaurantPic: auth.currentUser!.profilePic, app: app),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OrdersTab extends StatelessWidget {
  final List<OrderModel> orders;
  final AppProvider app;

  const _OrdersTab({required this.orders, required this.app});

  @override
  Widget build(BuildContext context) {
    final activeOrders = orders.where((o) => o.status != 'delivered' && o.status != 'completed' && o.status != 'cancelled').toList();
    final completedOrders = orders.where((o) => o.status == 'delivered' || o.status == 'completed').toList();

    // Stats calculations
    final double totalRevenue = completedOrders.fold(0.0, (sum, o) => sum + o.amount);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Revenue and Stats Cards
          Row(
            children: [
              Expanded(
                child: _buildStatCard('Active Orders', '${activeOrders.length}', Icons.pending_actions, Colors.orange),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildStatCard('Revenue', '₹${totalRevenue.toStringAsFixed(0)}', Icons.payments_outlined, Colors.green),
              ),
            ],
          ),
          const SizedBox(height: 24),

          // Active Orders Section
          const Text('Active Orders', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: FoodTheme.textDark)),
          const SizedBox(height: 12),
          if (activeOrders.isEmpty)
            const Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 40.0),
                child: Text('No active orders right now.', style: TextStyle(color: FoodTheme.textLight)),
              ),
            )
          else
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: activeOrders.length,
              itemBuilder: (context, index) {
                final order = activeOrders[index];
                return _buildOrderCard(context, order);
              },
            ),
          const SizedBox(height: 24),

          // Past Orders Section
          const Text('Completed Orders', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: FoodTheme.textDark)),
          const SizedBox(height: 12),
          if (completedOrders.isEmpty)
            const Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 20.0),
                child: Text('No past orders found.', style: TextStyle(color: FoodTheme.textLight)),
              ),
            )
          else
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: completedOrders.length.clamp(0, 5), // show top 5
              itemBuilder: (context, index) {
                final order = completedOrders[index];
                return Card(
                  color: Colors.white,
                  elevation: 0,
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    title: Text(order.customerName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    subtitle: Text('ID: ${order.id.substring(order.id.length - 6)} • ₹${order.amount.toStringAsFixed(0)}', style: const TextStyle(fontSize: 11)),
                    trailing: const Text('DELIVERED', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 11)),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Card(
      color: Colors.white,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade100)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: color.withOpacity(0.1),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 11, color: FoodTheme.textLight)),
                const SizedBox(height: 4),
                Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: FoodTheme.textDark)),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _buildOrderCard(BuildContext context, OrderModel order) {
    final hasRider = order.deliveryPartnerId.isNotEmpty;

    return Card(
      color: Colors.white,
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: Colors.grey.shade100)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Order #${order.id.substring(order.id.length - 6).toUpperCase()}', style: const TextStyle(fontWeight: FontWeight.bold, color: FoodTheme.textDark)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: FoodTheme.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    order.status.toUpperCase(),
                    style: const TextStyle(color: FoodTheme.primary, fontWeight: FontWeight.bold, fontSize: 10),
                  ),
                ),
              ],
            ),
            const Divider(height: 20),
            
            // Items list
            ...order.items.map((item) => Padding(
              padding: const EdgeInsets.only(bottom: 6.0),
              child: Row(
                children: [
                  Text('${item.quantity} x ', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: FoodTheme.primary)),
                  Expanded(child: Text(item.foodItem.name, style: const TextStyle(fontSize: 13, color: FoodTheme.textDark))),
                ],
              ),
            )),
            
            if (order.deliveryInstructions.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('Note: "${order.deliveryInstructions}"', style: const TextStyle(fontStyle: FontStyle.italic, fontSize: 11, color: FoodTheme.secondary)),
            ],
            const Divider(height: 20),
            
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Total: ₹${order.amount.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold, color: FoodTheme.textDark)),
                    Text('Delivery: ${hasRider ? order.deliveryPartnerName : "Finding Rider..."}', style: const TextStyle(fontSize: 10, color: FoodTheme.textLight)),
                  ],
                ),
                
                // Action Buttons based on status
                Row(
                  children: [
                    if (order.status == 'placed') ...[
                      ElevatedButton(
                        onPressed: () async {
                          final updated = order.copyWith(status: 'accepted');
                          await app.updateOrderDetails(updated);
                          // Trigger delivery matching search
                          await app.searchAndAssignDeliveryPartner(updated);
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.green, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8)),
                        child: const Text('Accept', style: TextStyle(color: Colors.white, fontSize: 12)),
                      ),
                    ] else if (order.status == 'accepted') ...[
                      ElevatedButton(
                        onPressed: () async {
                          await app.updateOrderDetails(order.copyWith(status: 'preparing'));
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: FoodTheme.primary, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8)),
                        child: const Text('Prepare', style: TextStyle(color: Colors.white, fontSize: 12)),
                      ),
                    ] else if (order.status == 'preparing') ...[
                      ElevatedButton(
                        onPressed: () async {
                          await app.updateOrderDetails(order.copyWith(status: 'picked_up'));
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: FoodTheme.secondary, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8)),
                        child: const Text('Ready / Picked Up', style: TextStyle(color: Colors.white, fontSize: 12)),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MenuTab extends StatefulWidget {
  final List<FoodItemModel> menu;
  final String restaurantId;
  final AppProvider app;

  const _MenuTab({required this.menu, required this.restaurantId, required this.app});

  @override
  State<_MenuTab> createState() => _MenuTabState();
}

class _MenuTabState extends State<_MenuTab> {
  void _showAddFoodDialog() {
    final nameController = TextEditingController();
    final descController = TextEditingController();
    final priceController = TextEditingController();
    final discountController = TextEditingController(text: '0');
    final prepController = TextEditingController(text: '15');
    final formKey = GlobalKey<FormState>();

    bool isVeg = true;
    String? uploadedImageUrl;
    bool isUploading = false;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            Future<void> pickImage() async {
              try {
                final picker = ImagePicker();
                final image = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
                if (image != null) {
                  setDialogState(() {
                    isUploading = true;
                  });
                  final bytes = await image.readAsBytes();
                  final url = await CloudinaryService.uploadImageBytes(bytes, image.name, folder: 'uc/restaurants/menu');
                  setDialogState(() {
                    uploadedImageUrl = url;
                    isUploading = false;
                  });
                }
              } catch (e) {
                setDialogState(() {
                  isUploading = false;
                });
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Upload failed: $e'), backgroundColor: Colors.red),
                );
              }
            }

            return AlertDialog(
              backgroundColor: Colors.white,
              title: const Text('Add Food Item', style: TextStyle(fontWeight: FontWeight.bold, color: FoodTheme.textDark)),
              content: Form(
                key: formKey,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextFormField(
                        controller: nameController,
                        decoration: const InputDecoration(labelText: 'Food Name'),
                        validator: (v) => v == null || v.isEmpty ? 'Required' : null,
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: descController,
                        decoration: const InputDecoration(labelText: 'Description / Category'),
                        validator: (v) => v == null || v.isEmpty ? 'Required' : null,
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: priceController,
                              decoration: const InputDecoration(labelText: 'Price (₹)'),
                              keyboardType: TextInputType.number,
                              validator: (v) => double.tryParse(v ?? '') == null ? 'Invalid price' : null,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: TextFormField(
                              controller: discountController,
                              decoration: const InputDecoration(labelText: 'Discount (%)'),
                              keyboardType: TextInputType.number,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: prepController,
                        decoration: const InputDecoration(labelText: 'Prep Time (mins)'),
                        keyboardType: TextInputType.number,
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          const Text('Veg Item?', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                          const Spacer(),
                          Switch(
                            value: isVeg,
                            onChanged: (val) {
                              setDialogState(() {
                                isVeg = val;
                              });
                            },
                            activeColor: Colors.green,
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      
                      Container(
                        height: 140,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade50,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.grey.shade200, width: 1.5),
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: InkWell(
                          onTap: isUploading ? null : pickImage,
                          child: isUploading
                              ? const Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      CircularProgressIndicator(color: FoodTheme.primary),
                                      SizedBox(height: 8),
                                      Text('Uploading photo...', style: TextStyle(fontSize: 12, color: FoodTheme.textLight)),
                                    ],
                                  ),
                                )
                              : (uploadedImageUrl != null
                                  ? Stack(
                                      fit: StackFit.expand,
                                      children: [
                                        Image.network(uploadedImageUrl!, fit: BoxFit.cover),
                                        Container(color: Colors.black.withOpacity(0.3)),
                                        const Center(
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Icon(Icons.camera_alt, color: Colors.white, size: 20),
                                              SizedBox(width: 8),
                                              Text('Change Photo', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                                            ],
                                          ),
                                        ),
                                      ],
                                    )
                                  : Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Icon(Icons.add_a_photo_outlined, color: FoodTheme.primary, size: 36),
                                        const SizedBox(height: 8),
                                        const Text('Tap to Choose Photo', style: TextStyle(color: FoodTheme.primary, fontWeight: FontWeight.bold, fontSize: 13)),
                                        const SizedBox(height: 4),
                                        Text('Supports JPG, PNG formats', style: TextStyle(color: Colors.grey.shade400, fontSize: 11)),
                                      ],
                                    )),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
                ElevatedButton(
                  onPressed: isUploading || uploadedImageUrl == null
                      ? null
                      : () async {
                          if (!formKey.currentState!.validate()) return;
                          final price = double.parse(priceController.text);
                          final discount = double.tryParse(discountController.text) ?? 0.0;
                          final prep = int.tryParse(prepController.text) ?? 15;

                          final newItem = FoodItemModel(
                            id: '',
                            restaurantId: widget.restaurantId,
                            name: nameController.text.trim(),
                            description: descController.text.trim(),
                            price: price,
                            discount: discount,
                            image: uploadedImageUrl!,
                            isVeg: isVeg,
                            isAvailable: true,
                            preparationTime: '$prep Mins',
                          );

                          await widget.app.createFoodItem(newItem);
                          if (context.mounted) Navigator.of(context).pop();
                        },
                  style: ElevatedButton.styleFrom(backgroundColor: FoodTheme.primary),
                  child: const Text('Add Item', style: TextStyle(color: Colors.white)),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FoodTheme.background,
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: FoodTheme.primary,
        onPressed: _showAddFoodDialog,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('Add Food', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
      body: widget.menu.isEmpty
          ? const Center(child: Text('Your menu is empty. Add items to show on the customer app.', style: TextStyle(color: FoodTheme.textLight)))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: widget.menu.length,
              itemBuilder: (context, index) {
                final item = widget.menu[index];
                return Card(
                  color: Colors.white,
                  margin: const EdgeInsets.only(bottom: 12),
                  elevation: 0,
                  child: ListTile(
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(item.image, width: 60, height: 60, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.fastfood)),
                    ),
                    title: Row(
                      children: [
                        Icon(Icons.circle, color: item.isVeg ? Colors.green : Colors.red, size: 10),
                        const SizedBox(width: 8),
                        Text(item.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      ],
                    ),
                    subtitle: Text('${item.description} • ₹${item.price.toStringAsFixed(0)}', style: const TextStyle(fontSize: 11)),
                    trailing: Switch(
                      value: item.isAvailable,
                      onChanged: (val) async {
                        // update availability
                        final updated = item.copyWith(isAvailable: val);
                        await widget.app.firebaseService.updateFoodItem(updated);
                      },
                      activeColor: FoodTheme.primary,
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class _StudioTab extends StatefulWidget {
  final String restaurantId;
  final String restaurantName;
  final String restaurantPic;
  final AppProvider app;

  const _StudioTab({required this.restaurantId, required this.restaurantName, required this.restaurantPic, required this.app});

  @override
  State<_StudioTab> createState() => _StudioTabState();
}

class _StudioTabState extends State<_StudioTab> {
  final _captionController = TextEditingController();
  String? _uploadedImageUrl;
  bool _isUploading = false;

  void _pickPostImage() async {
    try {
      final picker = ImagePicker();
      final image = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
      if (image != null) {
        setState(() {
          _isUploading = true;
        });
        final bytes = await image.readAsBytes();
        final url = await CloudinaryService.uploadImageBytes(bytes, image.name, folder: 'uc/posts');
        setState(() {
          _uploadedImageUrl = url;
          _isUploading = false;
        });
      }
    } catch (e) {
      setState(() {
        _isUploading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Upload failed: $e'), backgroundColor: Colors.red),
      );
    }
  }

  void _publishPost() async {
    final caption = _captionController.text.trim();
    if (caption.isEmpty || _uploadedImageUrl == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please add both a photo and caption.'), backgroundColor: Colors.orange),
      );
      return;
    }

    final post = PostModel(
      id: '',
      authorId: widget.restaurantId,
      authorName: widget.restaurantName,
      authorImage: widget.restaurantPic,
      imageUrl: _uploadedImageUrl!,
      videoUrl: '',
      caption: caption,
      timestamp: DateTime.now().millisecondsSinceEpoch,
    );

    await widget.app.addSocialPost(post);
    
    setState(() {
      _captionController.clear();
      _uploadedImageUrl = null;
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Post published successfully!'), backgroundColor: Colors.green),
      );
    }
  }

  @override
  void dispose() {
    _captionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Card(
        color: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: Colors.grey.shade100)),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('Restaurant Creator Studio', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: FoodTheme.textDark)),
              const SizedBox(height: 6),
              const Text('Post discount offers, new arrivals or customer greeting messages.', style: TextStyle(fontSize: 11, color: FoodTheme.textLight)),
              const Divider(height: 32),
              
              TextField(
                controller: _captionController,
                maxLines: 3,
                decoration: const InputDecoration(
                  hintText: 'Share a delicious update with customers...',
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 16),

              Container(
                height: 160,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.grey.shade50,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.grey.shade200, width: 1.5),
                ),
                clipBehavior: Clip.antiAlias,
                child: InkWell(
                  onTap: _isUploading ? null : (_uploadedImageUrl != null ? null : _pickPostImage),
                  child: _isUploading
                      ? const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CircularProgressIndicator(color: FoodTheme.primary),
                              SizedBox(height: 8),
                              Text('Uploading photo...', style: TextStyle(fontSize: 12, color: FoodTheme.textLight)),
                            ],
                          ),
                        )
                      : (_uploadedImageUrl != null
                          ? Stack(
                              fit: StackFit.expand,
                              children: [
                                Image.network(_uploadedImageUrl!, fit: BoxFit.cover),
                                Positioned(
                                  right: 8,
                                  top: 8,
                                  child: CircleAvatar(
                                    backgroundColor: Colors.black54,
                                    radius: 14,
                                    child: IconButton(
                                      padding: EdgeInsets.zero,
                                      icon: const Icon(Icons.close, size: 16, color: Colors.white),
                                      onPressed: () {
                                        setState(() => _uploadedImageUrl = null);
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            )
                          : Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.add_a_photo_outlined, color: FoodTheme.primary, size: 36),
                                const SizedBox(height: 8),
                                const Text('Tap to Choose Photo', style: TextStyle(color: FoodTheme.primary, fontWeight: FontWeight.bold, fontSize: 13)),
                                const SizedBox(height: 4),
                                Text('Supports JPG, PNG formats', style: TextStyle(color: Colors.grey.shade400, fontSize: 11)),
                              ],
                            )),
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _publishPost,
                style: ElevatedButton.styleFrom(backgroundColor: FoodTheme.primary, padding: const EdgeInsets.symmetric(vertical: 14)),
                child: const Text('PUBLISH UPDATE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
