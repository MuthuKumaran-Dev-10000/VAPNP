class DeliveryPartnerModel {
  final String id;
  final String name;
  final String mobile;
  final String email;
  final String address;
  final String bio;
  final String photo;
  final double rating;
  final bool isOnline;
  final double earnings;
  final double latitude;
  final double longitude;

  DeliveryPartnerModel({
    required this.id,
    required this.name,
    required this.mobile,
    required this.email,
    required this.address,
    required this.bio,
    required this.photo,
    this.rating = 4.5,
    this.isOnline = true,
    this.earnings = 0.0,
    this.latitude = 0.0,
    this.longitude = 0.0,
  });

  factory DeliveryPartnerModel.fromJson(Map<dynamic, dynamic> json, String id) {
    return DeliveryPartnerModel(
      id: id,
      name: json['name']?.toString() ?? '',
      mobile: (json['mobile'] ?? json['phone'])?.toString() ?? '',
      email: json['email']?.toString() ?? '',
      address: json['address']?.toString() ?? '',
      bio: json['bio']?.toString() ?? '',
      photo: (json['photo'] ?? json['profilePic'])?.toString() ?? '',
      rating: double.tryParse(json['rating']?.toString() ?? '4.5') ?? 4.5,
      isOnline: json['isOnline'] != false, // Default to true if not explicitly false
      earnings: double.tryParse(json['earnings']?.toString() ?? '0.0') ?? 0.0,
      latitude: double.tryParse(json['latitude']?.toString() ?? '0.0') ?? 0.0,
      longitude: double.tryParse(json['longitude']?.toString() ?? '0.0') ?? 0.0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'mobile': mobile,
      'email': email,
      'address': address,
      'bio': bio,
      'photo': photo,
      'rating': rating,
      'isOnline': isOnline,
      'earnings': earnings,
      'latitude': latitude,
      'longitude': longitude,
    };
  }

  DeliveryPartnerModel copyWith({
    String? id,
    String? name,
    String? mobile,
    String? email,
    String? address,
    String? bio,
    String? photo,
    double? rating,
    bool? isOnline,
    double? earnings,
    double? latitude,
    double? longitude,
  }) {
    return DeliveryPartnerModel(
      id: id ?? this.id,
      name: name ?? this.name,
      mobile: mobile ?? this.mobile,
      email: email ?? this.email,
      address: address ?? this.address,
      bio: bio ?? this.bio,
      photo: photo ?? this.photo,
      rating: rating ?? this.rating,
      isOnline: isOnline ?? this.isOnline,
      earnings: earnings ?? this.earnings,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
    );
  }
}
