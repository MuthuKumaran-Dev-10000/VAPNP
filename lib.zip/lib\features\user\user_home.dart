import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme.dart';
import '../../core/models/user_model.dart';
import '../../core/models/order_model.dart';
import '../../core/models/delivery_partner_model.dart';
import '../../core/models/restaurant_model.dart';
import '../../core/models/food_item_model.dart';
import '../../core/services/auth_provider.dart';
import '../../core/services/app_provider.dart';
import '../auth/login_screen.dart';
import 'temple_detail_screen.dart';
import 'cart_screen.dart';
import 'family_profiles_tab.dart';
import 'social_feed_tab.dart';
import 'meet_screen_mobile.dart';
import '../../widgets/offline_banner.dart';

class UserHome extends StatefulWidget {
  const UserHome({super.key});

  @override
  State<UserHome> createState() => _UserHomeState();
}

class _UserHomeState extends State<UserHome> {
  int _currentIndex = 1; // Default to explore tab
  String _searchQuery = '';
  
  // Discover Filters
  bool _filterVegOnly = false;
  String _selectedCuisine = 'All';
  double _minRating = 0.0;

  final List<String> _cuisines = ['All', 'Biryani', 'Pizza', 'Burger', 'Indian', 'Chinese', 'Desserts'];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final auth = Provider.of<AuthProvider>(context, listen: false);
      final app = Provider.of<AppProvider>(context, listen: false);
      if (auth.currentUser != null) {
        app.listenAllGlobalData();
        app.listenUserSessions(auth.currentUser!.uid, UserRole.customer);
      }
    });
  }

  void _launchLiveTracking(String orderId) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => getInAppMeetScreen(orderId),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final app = Provider.of<AppProvider>(context);

    if (auth.currentUser == null) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(color: FoodTheme.primary),
        ),
      );
    }

    // Filter restaurants based on search and selected filters
    final filteredRestaurants = app.restaurants.where((r) {
      final matchesSearch = r.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          r.description.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          r.address.toLowerCase().contains(_searchQuery.toLowerCase());
      
      final matchesVeg = !_filterVegOnly || r.isVegOnly;
      final matchesRating = r.rating >= _minRating;
      final matchesCuisine = _selectedCuisine == 'All' || r.description.toLowerCase().contains(_selectedCuisine.toLowerCase());

      return matchesSearch && matchesVeg && matchesRating && matchesCuisine;
    }).toList();

    // Filter food items based on search query
    final filteredFoodItems = app.foodItems.where((f) {
      final matchesSearch = f.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          f.description.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesVeg = !_filterVegOnly || f.isVeg;
      return matchesSearch && matchesVeg;
    }).toList();

    final tabs = [
      const SocialFeedTab(),
      _buildExploreTab(context, app, filteredRestaurants, filteredFoodItems),
      _buildOrdersTab(context, app),
      const FamilyProfilesTab(),
    ];

    return Scaffold(
      backgroundColor: FoodTheme.background,
      appBar: AppBar(
        title: Text(_getAppBarTitle(), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        backgroundColor: Colors.white,
        elevation: 0,
        actions: [
          if (_currentIndex == 1)
            Stack(
              alignment: Alignment.center,
              children: [
                IconButton(
                  icon: const Icon(Icons.shopping_bag_outlined),
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const CartScreen()),
                    );
                  },
                ),
                if (app.cart.isNotEmpty)
                  Positioned(
                    right: 6,
                    top: 6,
                    child: CircleAvatar(
                      radius: 8,
                      backgroundColor: FoodTheme.secondary,
                      child: Text(
                        '${app.cart.length}',
                        style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
              ],
            ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await auth.signOut();
              if (mounted) {
                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                );
              }
            },
          ),
        ],
      ),
      body: Column(
        children: [
          const OfflineBanner(),
          Expanded(child: tabs[_currentIndex]),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() {
          _currentIndex = index;
          _searchQuery = ''; // clear query
        }),
        selectedItemColor: FoodTheme.primary,
        unselectedItemColor: FoodTheme.textLight,
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.white,
        selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11),
        unselectedLabelStyle: const TextStyle(fontSize: 10),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.style_outlined), label: 'Feed'),
          BottomNavigationBarItem(icon: Icon(Icons.explore_outlined), label: 'Explore'),
          BottomNavigationBarItem(icon: Icon(Icons.receipt_long_outlined), label: 'Orders'),
          BottomNavigationBarItem(icon: Icon(Icons.home_work_outlined), label: 'Addresses'),
        ],
      ),
    );
  }

  String _getAppBarTitle() {
    switch (_currentIndex) {
      case 0:
        return 'Instagram Food Feed';
      case 1:
        return 'QuickBites';
      case 2:
        return 'Active Orders';
      case 3:
        return 'Delivery Locations';
      default:
        return 'QuickBites';
    }
  }

  // --- TAB 1: EXPLORE DISCOVERY TAB ---
  Widget _buildExploreTab(BuildContext context, AppProvider app, List<RestaurantModel> restaurantList, List<FoodItemModel> foodItemList) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Dynamic Header Location + Search
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(24),
                bottomRight: Radius.circular(24),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: const [
                    Icon(Icons.location_on, color: FoodTheme.secondary, size: 20),
                    SizedBox(width: 6),
                    Text(
                      'Indiranagar, Bangalore',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: FoodTheme.textDark),
                    ),
                    Icon(Icons.keyboard_arrow_down, color: FoodTheme.textLight),
                  ],
                ),
                const SizedBox(height: 16),
                // Premium Styled Search Bar
                TextField(
                  onChanged: (val) => setState(() => _searchQuery = val),
                  decoration: InputDecoration(
                    hintText: 'Search restaurants or food items...',
                    prefixIcon: const Icon(Icons.search, color: FoodTheme.textLight),
                    filled: true,
                    fillColor: FoodTheme.background,
                    contentPadding: const EdgeInsets.symmetric(vertical: 0),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          
          // Filters Deck
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  FilterChip(
                    label: const Text('Veg Only'),
                    selected: _filterVegOnly,
                    onSelected: (val) => setState(() => _filterVegOnly = val),
                    selectedColor: Colors.green.withOpacity(0.1),
                    checkmarkColor: Colors.green,
                  ),
                  const SizedBox(width: 8),
                  DropdownButton<String>(
                    value: _selectedCuisine,
                    underline: const SizedBox(),
                    items: _cuisines.map((c) => DropdownMenuItem(value: c, child: Text('$c Cuisine'))).toList(),
                    onChanged: (val) {
                      if (val != null) setState(() => _selectedCuisine = val);
                    },
                    style: const TextStyle(color: FoodTheme.textDark, fontWeight: FontWeight.bold, fontSize: 13),
                  ),
                  const SizedBox(width: 12),
                  FilterChip(
                    label: const Text('Rating 4.0+'),
                    selected: _minRating == 4.0,
                    onSelected: (val) => setState(() => _minRating = val ? 4.0 : 0.0),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Categories Shortcuts (Zomato Style)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Eat What You Love', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: FoodTheme.textDark)),
                const SizedBox(height: 12),
                SizedBox(
                  height: 90,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: _cuisines.length - 1,
                    itemBuilder: (context, index) {
                      final name = _cuisines[index + 1];
                      final isSelected = _selectedCuisine == name;
                      
                      // Mock cuisine icons
                      final icons = {
                        'Biryani': Icons.rice_bowl_outlined,
                        'Pizza': Icons.local_pizza_outlined,
                        'Burger': Icons.lunch_dining_outlined,
                        'Indian': Icons.set_meal_outlined,
                        'Chinese': Icons.ramen_dining_outlined,
                        'Desserts': Icons.icecream_outlined,
                      };

                      return Padding(
                        padding: const EdgeInsets.only(right: 14.0),
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              _selectedCuisine = isSelected ? 'All' : name;
                            });
                          },
                          child: Column(
                            children: [
                              CircleAvatar(
                                radius: 26,
                                backgroundColor: isSelected ? FoodTheme.primary : Colors.white,
                                child: Icon(icons[name] ?? Icons.fastfood, color: isSelected ? Colors.white : FoodTheme.primary),
                              ),
                              const SizedBox(height: 6),
                              Text(name, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: isSelected ? FoodTheme.primary : FoodTheme.textDark)),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Recommended Food Items list
          if (_searchQuery.isNotEmpty && foodItemList.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: const Text('Matched Dishes', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: FoodTheme.textDark)),
            ),
            const SizedBox(height: 8),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: foodItemList.length,
              itemBuilder: (context, index) {
                final f = foodItemList[index];
                return Card(
                  color: Colors.white,
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    leading: Image.network(f.image, width: 50, height: 50, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.fastfood)),
                    title: Text(f.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('₹${f.price.toStringAsFixed(0)}'),
                    trailing: ElevatedButton(
                      onPressed: () {
                        app.addToCart(f);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Added ${f.name} to cart!'), backgroundColor: FoodTheme.primary, duration: const Duration(seconds: 1)),
                        );
                      },
                      style: ElevatedButton.styleFrom(backgroundColor: FoodTheme.primary, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8)),
                      child: const Text('ADD', style: TextStyle(fontSize: 12)),
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 16),
          ],

          // Featured Restaurants
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: const Text('Featured Kitchens', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: FoodTheme.textDark)),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 180,
            child: restaurantList.isEmpty
                ? const Center(child: Text('No featured restaurants.', style: TextStyle(color: FoodTheme.textLight)))
                : ListView.builder(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.only(left: 16),
                    itemCount: restaurantList.length,
                    itemBuilder: (context, index) {
                      final r = restaurantList[index];
                      return Container(
                        width: 220,
                        margin: const EdgeInsets.only(right: 16),
                        child: Card(
                          color: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          elevation: 2,
                          child: InkWell(
                            onTap: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(builder: (_) => TempleDetailScreen(temple: r)),
                              );
                            },
                            borderRadius: BorderRadius.circular(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: const BorderRadius.only(topLeft: Radius.circular(16), topRight: Radius.circular(16)),
                                  child: Image.network(
                                    r.coverImage,
                                    height: 100,
                                    width: double.infinity,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Container(height: 100, color: FoodTheme.primary.withOpacity(0.1)),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(r.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis),
                                      const SizedBox(height: 2),
                                      Row(
                                        children: [
                                          const Icon(Icons.star, color: Colors.amber, size: 12),
                                          const SizedBox(width: 2),
                                          Text('${r.rating}', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
                                          const Spacer(),
                                          const Icon(Icons.location_on, color: FoodTheme.secondary, size: 12),
                                          const SizedBox(width: 2),
                                          const Text('3.2 km', style: TextStyle(fontSize: 10)),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
          const SizedBox(height: 24),

          // Restaurant List
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('All Restaurants', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: FoodTheme.textDark)),
                Text('${restaurantList.length} places', style: const TextStyle(color: FoodTheme.textLight, fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          restaurantList.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32.0),
                    child: Text('No restaurants found matching criteria.', style: TextStyle(color: FoodTheme.textLight)),
                  ),
                )
              : ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: restaurantList.length,
                  itemBuilder: (context, index) {
                    final r = restaurantList[index];
                    return Card(
                      color: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      margin: const EdgeInsets.only(bottom: 16),
                      elevation: 2,
                      child: InkWell(
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => TempleDetailScreen(temple: r)),
                          );
                        },
                        borderRadius: BorderRadius.circular(20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Stack(
                              children: [
                                ClipRRect(
                                  borderRadius: const BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20)),
                                  child: Image.network(
                                    r.coverImage,
                                    height: 160,
                                    width: double.infinity,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Container(height: 160, color: FoodTheme.primary.withOpacity(0.1)),
                                  ),
                                ),
                                Positioned(
                                  top: 12,
                                  right: 12,
                                  child: CircleAvatar(
                                    backgroundColor: Colors.white,
                                    radius: 16,
                                    child: Icon(
                                      r.isVegOnly ? Icons.circle : Icons.circle,
                                      color: r.isVegOnly ? Colors.green : Colors.red,
                                      size: 14,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Row(
                                children: [
                                  CircleAvatar(
                                    backgroundImage: NetworkImage(r.profileImage),
                                    radius: 20,
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(r.name, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: FoodTheme.textDark)),
                                        const SizedBox(height: 2),
                                        Text(r.description, style: const TextStyle(fontSize: 11, color: FoodTheme.textLight), maxLines: 1, overflow: TextOverflow.ellipsis),
                                      ],
                                    ),
                                  ),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                        decoration: BoxDecoration(color: Colors.green, borderRadius: BorderRadius.circular(6)),
                                        child: Row(
                                          children: [
                                            Text('${r.rating}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11)),
                                            const SizedBox(width: 2),
                                            const Icon(Icons.star, color: Colors.white, size: 10),
                                          ],
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      const Text('30-40 Mins', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600)),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  // --- TAB 2: MY ORDERS LIST ---
  Widget _buildOrdersTab(BuildContext context, AppProvider app) {
    if (app.orders.isEmpty) {
      return const Center(child: Text('No orders placed yet.', style: TextStyle(color: FoodTheme.textLight)));
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: app.orders.length,
      itemBuilder: (context, index) {
        final o = app.orders[index];
        
        Color statusColor = Colors.orange;
        if (o.status == 'placed' || o.status == 'accepted') statusColor = Colors.blue;
        if (o.status == 'preparing' || o.status == 'picked_up' || o.status == 'on_the_way') statusColor = Colors.purple;
        if (o.status == 'completed' || o.status == 'delivered') statusColor = Colors.green;
        if (o.status == 'cancelled') statusColor = Colors.red;

        return Card(
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          elevation: 2,
          margin: const EdgeInsets.only(bottom: 16),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: FoodTheme.primary.withOpacity(0.1),
                      child: const Icon(Icons.restaurant, color: FoodTheme.primary),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(o.restaurantName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                          Text(
                            'Order #${o.id.substring(0, 5).toUpperCase()}',
                            style: const TextStyle(color: FoodTheme.textLight, fontSize: 10),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(color: statusColor.withOpacity(0.15), borderRadius: BorderRadius.circular(6)),
                      child: Text(
                        o.status.toUpperCase(),
                        style: TextStyle(color: statusColor, fontWeight: FontWeight.bold, fontSize: 9),
                      ),
                    ),
                  ],
                ),
                const Divider(height: 24),
                // Items overview
                ...o.items.map((item) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 6.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('${item.foodItem.name} x${item.quantity}', style: const TextStyle(fontSize: 12.5)),
                        Text('₹${(item.foodItem.price * item.quantity).toStringAsFixed(0)}', style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  );
                }).toList(),
                const Divider(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Total Amount Paid', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12.5)),
                    Text('₹${o.amount.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green, fontSize: 14)),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _downloadReceipt(o),
                        icon: const Icon(Icons.receipt_long, size: 16),
                        label: const Text('RECEIPT', style: TextStyle(fontSize: 12)),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: FoodTheme.primary),
                          foregroundColor: FoodTheme.primary,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () => _launchLiveTracking(o.id),
                        icon: const Icon(Icons.map, size: 16),
                        label: const Text('TRACK', style: TextStyle(fontSize: 12)),
                        style: ElevatedButton.styleFrom(backgroundColor: FoodTheme.primary),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _downloadReceipt(OrderModel order) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('PDF invoice generated for Order #${order.id.substring(0, 5).toUpperCase()}'), backgroundColor: FoodTheme.primary),
    );
  }
}
