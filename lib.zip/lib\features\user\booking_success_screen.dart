import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../core/models/order_model.dart';
import '../../core/services/pdf_service.dart';
import 'meet_screen_mobile.dart';

class BookingSuccessScreen extends StatefulWidget {
  final String devoteeName;
  final String templeName;
  final String upiReference;

  const BookingSuccessScreen({
    super.key,
    required this.devoteeName,
    required this.templeName,
    required this.upiReference,
  });

  @override
  State<BookingSuccessScreen> createState() => _BookingSuccessScreenState();
}

class _BookingSuccessScreenState extends State<BookingSuccessScreen> {
  bool _isGeneratingPdf = false;

  Future<void> _downloadPdfReceipt() async {
    setState(() => _isGeneratingPdf = true);
    try {
      // Create a temporary mock OrderModel to generate the PDF receipt
      final mockOrder = OrderModel(
        id: widget.upiReference.isNotEmpty ? widget.upiReference : 'ORD_${DateTime.now().millisecondsSinceEpoch.toString().substring(5)}',
        customerId: 'temp_user',
        customerName: widget.devoteeName,
        restaurantId: 'temp_rest',
        restaurantName: widget.templeName,
        deliveryPartnerId: '',
        deliveryPartnerName: 'Delivery Rider',
        items: [],
        amount: 0.0,
        status: 'placed',
        paymentMethod: 'online',
        paymentStatus: 'success',
        paymentReference: widget.upiReference,
        createdAt: DateTime.now().millisecondsSinceEpoch,
        deliveryAddress: 'Your Selected Address',
        deliveryInstructions: '',
      );

      final bytes = await PdfService.generateReceiptBytes(mockOrder);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Receipt PDF generated (${bytes.length} bytes)'),
            action: SnackBarAction(
              label: 'OK',
              textColor: Colors.white,
              onPressed: () {},
            ),
            backgroundColor: FoodTheme.primary,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error generating receipt: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isGeneratingPdf = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FoodTheme.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 40.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              // Beautiful glowing check circle
              Center(
                child: Container(
                  height: 100,
                  width: 100,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    border: Border.all(color: FoodTheme.primary, width: 3),
                    boxShadow: FoodTheme.softShadow,
                  ),
                  child: const Icon(
                    Icons.check_circle,
                    color: FoodTheme.primary,
                    size: 64,
                  ),
                ),
              ),
              const SizedBox(height: 32),
              Text(
                'Order Placed!',
                style: Theme.of(context).textTheme.displayMedium,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              const Text(
                'Your order has been sent to the kitchen. You can track its live preparation and delivery en-route.',
                style: TextStyle(color: FoodTheme.textLight, height: 1.5, fontSize: 13),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              // Order Details Summary Card
              Card(
                color: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                elevation: 0,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey.shade100),
                  ),
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      _buildDetailRow('Restaurant', widget.templeName),
                      const SizedBox(height: 12),
                      _buildDetailRow('Customer', widget.devoteeName),
                      const SizedBox(height: 12),
                      _buildDetailRow('Order ID / Ref', widget.upiReference),
                      const SizedBox(height: 12),
                      _buildDetailRow('Status', 'Preparing', isHighlight: true),
                    ],
                  ),
                ),
              ),
              const Spacer(),
              
              // Action Buttons
              if (widget.upiReference.isNotEmpty && !widget.upiReference.startsWith('pay_')) ...[
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.of(context).pushReplacement(
                      MaterialPageRoute(
                        builder: (_) => MobileMeetScreen(orderId: widget.upiReference),
                      ),
                    );
                  },
                  icon: const Icon(Icons.delivery_dining, color: Colors.white),
                  label: const Text('TRACK LIVE ORDER'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: FoodTheme.primary,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
                const SizedBox(height: 12),
              ],
              
              _isGeneratingPdf
                  ? const Center(child: CircularProgressIndicator(color: FoodTheme.primary))
                  : OutlinedButton.icon(
                      onPressed: _downloadPdfReceipt,
                      icon: const Icon(Icons.picture_as_pdf, color: FoodTheme.primary),
                      label: const Text('DOWNLOAD PDF RECEIPT', style: TextStyle(color: FoodTheme.primary, fontWeight: FontWeight.bold)),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: FoodTheme.primary, width: 1.5),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                    ),
              const SizedBox(height: 16),
              TextButton(
                onPressed: () {
                  Navigator.of(context).popUntil((route) => route.isFirst);
                },
                child: const Text(
                  'GO TO HOME',
                  style: TextStyle(color: FoodTheme.textLight, fontWeight: FontWeight.bold, fontSize: 14),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value, {bool isHighlight = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontWeight: FontWeight.w500, color: FoodTheme.textLight),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Text(
            value,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: isHighlight ? FoodTheme.primary : FoodTheme.textDark,
            ),
            textAlign: TextAlign.right,
          ),
        ),
      ],
    );
  }
}
