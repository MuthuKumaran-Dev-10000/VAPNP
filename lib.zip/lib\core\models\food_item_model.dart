class FoodItemModel {
  final String id;
  final String restaurantId;
  final String name;
  final String description;
  final double price;
  final double discount; // percentage discount (e.g. 10 for 10% off)
  final String image;
  final bool isVeg;
  final bool isAvailable;
  final String preparationTime; // e.g. "20 Mins"

  FoodItemModel({
    required this.id,
    required this.restaurantId,
    required this.name,
    required this.description,
    required this.price,
    this.discount = 0.0,
    required this.image,
    this.isVeg = true,
    this.isAvailable = true,
    this.preparationTime = "20 Mins",
  });

  factory FoodItemModel.fromJson(Map<dynamic, dynamic> json, String id) {
    return FoodItemModel(
      id: id,
      restaurantId: (json['restaurantId'] ?? json['templeId'])?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      description: json['description']?.toString() ?? '',
      price: double.tryParse((json['price'] ?? json['amount'])?.toString() ?? '0') ?? 0.0,
      discount: double.tryParse(json['discount']?.toString() ?? '0') ?? 0.0,
      image: json['image']?.toString() ?? '',
      isVeg: json['isVeg'] != false, // Default to veg unless explicitly false
      isAvailable: json['isAvailable'] != false,
      preparationTime: json['preparationTime']?.toString() ?? json['duration']?.toString() ?? '20 Mins',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'restaurantId': restaurantId,
      'name': name,
      'description': description,
      'price': price,
      'discount': discount,
      'image': image,
      'isVeg': isVeg,
      'isAvailable': isAvailable,
      'preparationTime': preparationTime,
    };
  }

  FoodItemModel copyWith({
    String? id,
    String? restaurantId,
    String? name,
    String? description,
    double? price,
    double? discount,
    String? image,
    bool? isVeg,
    bool? isAvailable,
    String? preparationTime,
  }) {
    return FoodItemModel(
      id: id ?? this.id,
      restaurantId: restaurantId ?? this.restaurantId,
      name: name ?? this.name,
      description: description ?? this.description,
      price: price ?? this.price,
      discount: discount ?? this.discount,
      image: image ?? this.image,
      isVeg: isVeg ?? this.isVeg,
      isAvailable: isAvailable ?? this.isAvailable,
      preparationTime: preparationTime ?? this.preparationTime,
    );
  }
}
